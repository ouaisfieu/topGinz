### 🏠 **Les Maisons Astrologiques – Récapitulatif Complet**

Les **maisons astrologiques** représentent les **domaines de la vie** où s’expriment les énergies des **planètes** et des **signes**. Elles sont **au nombre de 12**, formant un cycle complet qui **décrit notre existence sur Terre**.

- Chaque **planète** placée dans une maison **indique comment son énergie s’exprime dans ce domaine**.
- Chaque **signe** au début d’une maison **modifie son expression**.

---

## 🏠 **Les 12 Maisons Astrologiques : Signification et Influence**

|🏠 **Maison**|🔎 **Domaine de Vie**|🎭 **Thème Principal**|🏡 **Maître Naturel**|⏳ **Mode**|
|---|---|---|---|---|
|**[[Maison 1]]**|Identité, apparence|Personnalité, première impression|[[Bélier]] ♈|Angulaire|
|**[[Maison 2]]**|Argent, valeurs|Sécurité matérielle, possessions|[[Taureau]] ♉|Succédante|
|**[[Maison 3]]**|Communication, apprentissage|Esprit, échanges, relations proches|[[Gémeaux]] ♊|Cadente|
|**[[Maison 4]]**|Racines, foyer|Famille, origines, ancrage|[[Cancer]] ♋|Angulaire|
|**[[Maison 5]]**|Créativité, plaisir|Amour, jeu, expression|[[Lion]] ♌|Succédante|
|**[[Maison 6]]**|Travail, santé|Discipline, service, quotidien|[[Vierge]] ♍|Cadente|
|**[[Maison 7]]**|Relations, mariage|Partenariats, engagements|[[Balance]] ♎|Angulaire|
|**[[Maison 8]]**|Transformation, mystères|Crises, sexualité, héritages|[[Scorpion]] ♏|Succédante|
|**[[Maison 9]]**|Expansion, voyages|Croyances, études supérieures, exploration|[[Sagittaire]] ♐|Cadente|
|**[[Maison 10]]**|Carrière, destinée|Réputation, ambitions, succès|[[Capricorne]] ♑|Angulaire|
|**[[Maison 11]]**|Amitiés, projets collectifs|Communauté, innovation|[[Verseau]] ♒|Succédante|
|**[[Maison 12]]**|Inconscient, spiritualité|Épreuves, karma, solitude|[[Poissons]] ♓|Cadente|

---

## 🔹 **Maisons Angulaires, Succédantes et Cadentes**

Les maisons sont divisées en **trois catégories** selon leur **impact** :

1. **🏛️ Maisons Angulaires (1, 4, 7, 10)** → **Puissance et affirmation**
    
    - Représentent **les grandes structures de notre vie** (identité, famille, relations, carrière).
    - Les planètes ici sont **fortement visibles et influentes**.
2. **💎 Maisons Succédantes (2, 5, 8, 11)** → **Stabilité et ressources**
    
    - Indiquent **nos talents, notre confort et notre résistance au changement**.
    - Les planètes ici travaillent **dans la durée**.
3. **📚 Maisons Cadentes (3, 6, 9, 12)** → **Adaptabilité et réflexion**
    
    - Liées aux **idées, à l’apprentissage et aux transitions**.
    - Les planètes ici sont **moins actives mais essentielles pour l’évolution personnelle**.

---

## 🏠 **Détail des Maisons Astrologiques**

### **1️⃣ [[Maison 1]] – L’Ascendant et l’Identité**

💡 **Thème principal** : Image de soi, première impression, style personnel  
🏡 **Signe naturel** : [[Bélier]] ♈  
⚡ **Impact** : Influence directe sur le tempérament et l’apparence physique  
🔥 **Exemple** : [[Mars en Maison 1]] → Forte énergie, impulsivité

---

### **2️⃣ [[Maison 2]] – L’Argent et les Valeurs**

💡 **Thème principal** : Sécurité matérielle, possessions, ressources personnelles  
🏡 **Signe naturel** : [[Taureau]] ♉  
⚡ **Impact** : Reflète notre rapport à l’argent et aux biens matériels  
🔥 **Exemple** : [[Vénus en Maison 2]] → Succès financier, goût du luxe

---

### **3️⃣ [[Maison 3]] – La Communication et l’Environnement Proche**

💡 **Thème principal** : Apprentissage, échanges, relations avec la fratrie  
🏡 **Signe naturel** : [[Gémeaux]] ♊  
⚡ **Impact** : Influence notre manière de parler, d’écrire et de penser  
🔥 **Exemple** : [[Mercure en Maison 3]] → Esprit vif, curiosité naturelle

---

### **4️⃣ [[Maison 4]] – Le Foyer et les Racines**

💡 **Thème principal** : Famille, enfance, mémoire émotionnelle  
🏡 **Signe naturel** : [[Cancer]] ♋  
⚡ **Impact** : Définit nos bases affectives et notre attachement aux racines  
🔥 **Exemple** : [[Lune en Maison 4]] → Attachement fort au foyer

---

### **5️⃣ [[Maison 5]] – La Créativité et les Loisirs**

💡 **Thème principal** : Amour, enfants, expression personnelle  
🏡 **Signe naturel** : [[Lion]] ♌  
⚡ **Impact** : Influence notre rapport au jeu et aux plaisirs  
🔥 **Exemple** : [[Soleil en Maison 5]] → Besoin d’être vu et admiré

---

### **6️⃣ [[Maison 6]] – Le Travail et la Santé**

💡 **Thème principal** : Quotidien, discipline, hygiène de vie  
🏡 **Signe naturel** : [[Vierge]] ♍  
⚡ **Impact** : Influence nos habitudes et notre approche du travail  
🔥 **Exemple** : [[Saturne en Maison 6]] → Sens du devoir et rigueur

---

### **7️⃣ [[Maison 7]] – Les Relations et le Mariage**

💡 **Thème principal** : Partenariats, engagements, ennemis déclarés  
🏡 **Signe naturel** : [[Balance]] ♎  
⚡ **Impact** : Indique notre manière de nous relier aux autres  
🔥 **Exemple** : [[Vénus en Maison 7]] → Charisme dans les relations

---

### **8️⃣ [[Maison 8]] – Les Transformations et le Mystère**

💡 **Thème principal** : Sexualité, crises, héritages, occultisme  
🏡 **Signe naturel** : [[Scorpion]] ♏  
⚡ **Impact** : Confrontation à la mort symbolique et aux renaissances  
🔥 **Exemple** : [[Pluton en Maison 8]] → Transformation intense

---

### **9️⃣ [[Maison 9]] – L’Expansion et les Croyances**

💡 **Thème principal** : Spiritualité, voyages, études supérieures  
🏡 **Signe naturel** : [[Sagittaire]] ♐  
⚡ **Impact** : Besoin d’explorer au-delà des limites connues  
🔥 **Exemple** : [[Jupiter en Maison 9]] → Soif de découverte et d’apprentissage

---

### **🔟 [[Maison 10]] – La Carrière et la Destinée**

💡 **Thème principal** : Réputation, ambition, mission sociale  
🏡 **Signe naturel** : [[Capricorne]] ♑  
⚡ **Impact** : Influence notre statut et notre réussite professionnelle  
🔥 **Exemple** : [[Saturne en Maison 10]] → Carrière bâtie sur l’effort

---

### **1️⃣1️⃣ [[Maison 11]] – Les Amis et les Projets**

💡 **Thème principal** : Communauté, espoirs, aspirations collectives  
🏡 **Signe naturel** : [[Verseau]] ♒  
⚡ **Impact** : Influence nos engagements sociaux et nos amitiés  
🔥 **Exemple** : [[Uranus en Maison 11]] → Relations atypiques

---

### **1️⃣2️⃣ [[Maison 12]] – L’Inconscient et le Karma**

💡 **Thème principal** : Solitude, spiritualité, épreuves  
🏡 **Signe naturel** : [[Poissons]] ♓  
⚡ **Impact** : Représente les forces cachées et le lien au divin  
🔥 **Exemple** : [[Neptune en Maison 12]] → Mysticisme profond