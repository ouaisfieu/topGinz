### 🌌 **Récapitulatif des Planètes en Astrologie** 🌌

Les planètes en astrologie symbolisent **différentes forces influençant notre personnalité, nos comportements et notre destinée**. Elles sont divisées en **planètes personnelles**, **planètes sociales** et **planètes transpersonnelles**.

---

## 🌟 **Les Planètes Personnelles** (Influence individuelle, rapide)

Ces planètes ont une influence **directe sur la personnalité et l’expérience quotidienne**.

|🌞 **Planète**|🌟 **Rôle**|💫 **Domicile**|🔼 **Exaltation**|❌ **Exil**|⬇️ **Chute**|
|---|---|---|---|---|---|
|☀️ **Soleil**|Identité, volonté, rayonnement|♌ **Lion**|♈ **Bélier**|♒ **Verseau**|♎ **Balance**|
|🌙 **Lune**|Émotions, inconscient, mémoire|♋ **Cancer**|♉ **Taureau**|♑ **Capricorne**|♏ **Scorpion**|
|🟠 **Mercure**|Intellect, communication, logique|♊ **Gémeaux**, ♍ **Vierge**|♍ **Vierge**|♐ **Sagittaire**, ♓ **Poissons**|♓ **Poissons**|
|💖 **Vénus**|Amour, beauté, plaisir|♉ **Taureau**, ♎ **Balance**|♓ **Poissons**|♏ **Scorpion**, ♈ **Bélier**|♍ **Vierge**|
|🔥 **Mars**|Action, désir, combativité|♈ **Bélier**, ♏ **Scorpion**|♑ **Capricorne**|♎ **Balance**, ♉ **Taureau**|♋ **Cancer**|

---

## 🌍 **Les Planètes Sociales** (Influence collective, cycle moyen)

Ces planètes influencent **notre rapport aux autres et à la société**.

|🌞 **Planète**|🌟 **Rôle**|💫 **Domicile**|🔼 **Exaltation**|❌ **Exil**|⬇️ **Chute**|
|---|---|---|---|---|---|
|🌟 **Jupiter**|Expansion, chance, optimisme|♐ **Sagittaire**, ♓ **Poissons**|♋ **Cancer**|♊ **Gémeaux**, ♍ **Vierge**|♑ **Capricorne**|
|⏳ **Saturne**|Responsabilité, discipline, rigueur|♑ **Capricorne**, ♒ **Verseau**|♎ **Balance**|♋ **Cancer**, ♌ **Lion**|♈ **Bélier**|

---

## 🔮 **Les Planètes Transpersonnelles** (Influence générationnelle, cycle long)

Ces planètes représentent **les forces inconscientes et collectives**.

|🌞 **Planète**|🌟 **Rôle**|💫 **Domicile**|🔼 **Exaltation**|❌ **Exil**|⬇️ **Chute**|
|---|---|---|---|---|---|
|⚡ **Uranus**|Rébellion, innovation, rupture|♒ **Verseau**|♏ **Scorpion**|♌ **Lion**|♉ **Taureau**|
|🌊 **Neptune**|Rêve, illusion, spiritualité|♓ **Poissons**|♌ **Lion** (trad.)|♍ **Vierge**|♒ **Verseau**|
|🖤 **Pluton**|Transformation, pouvoir, renaissance|♏ **Scorpion**|♈ **Bélier** (trad.)|♉ **Taureau**|♎ **Balance**|

---

## 🏠 **Influence des Planètes selon leur Catégorie**

🔹 **Planètes personnelles** → **Influence directe sur la personnalité et le quotidien**  
🔹 **Planètes sociales** → **Régulent l’évolution personnelle au sein de la société**  
🔹 **Planètes transpersonnelles** → **Agissent sur l’évolution collective et les grandes transformations**

---

## ⚡ **Les Énergies des Planètes**

|Planète|☀️ Positif|🌑 Négatif|
|---|---|---|
|☀️ **Soleil**|Confiance, rayonnement, leadership|Orgueil, autoritarisme|
|🌙 **Lune**|Sensibilité, intuition, mémoire|Instabilité, passivité|
|🟠 **Mercure**|Intelligence, communication, vivacité|Mensonge, dispersion|
|💖 **Vénus**|Amour, harmonie, sociabilité|Superficialité, dépendance affective|
|🔥 **Mars**|Énergie, courage, initiative|Colère, impulsivité, agressivité|
|🌟 **Jupiter**|Chance, croissance, optimisme|Exagération, excès, naïveté|
|⏳ **Saturne**|Discipline, patience, sagesse|Rigidité, frustration, peur|
|⚡ **Uranus**|Innovation, génie, indépendance|Chaos, imprévisibilité, rébellion aveugle|
|🌊 **Neptune**|Inspiration, spiritualité, compassion|Illusion, confusion, fuite|
|🖤 **Pluton**|Transformation, résilience, puissance|Obsession, manipulation, destruction|

---

## 🔮 **Les Planètes en Action dans un Thème Astral**

### **1️⃣ En Signe → Personnalité et expression**

Chaque planète en signe influence **la manière dont elle se manifeste** (ex : [[Mars en Bélier]] = action rapide et impulsive, [[Mars en Taureau]] = action réfléchie et endurante).

### **2️⃣ En Maison → Domaine d’application**

Chaque planète en maison indique **où nous vivons son énergie** (ex : [[Jupiter en Maison 10]] = succès professionnel, [[Neptune en Maison 5]] = créativité mystique).

### **3️⃣ En Aspect → Interaction des énergies**

Les aspects entre planètes déterminent **la fluidité ou la tension entre elles**.

- **Conjonction** → Fusion des énergies (ex : [[Soleil conjoint Mercure]] = communication claire et rapide)
- **Trigone/Sextile** → Harmonie et facilitation (ex : [[Vénus trigone Jupiter]] = charme naturel et chance en amour)
- **Carré/Opposition** → Tensions et défis (ex : [[Saturne carré Lune]] = difficulté à exprimer les émotions)

---

### 🔥 **Résumé des Rôles des Planètes**

|🌞 **Planète**|🔍 **Rôle Principal**|
|---|---|
|☀️ **Soleil**|Identité et rayonnement|
|🌙 **Lune**|Émotions et inconscient|
|🟠 **Mercure**|Esprit et communication|
|💖 **Vénus**|Amour et plaisir|
|🔥 **Mars**|Action et combativité|
|🌟 **Jupiter**|Expansion et chance|
|⏳ **Saturne**|Discipline et épreuves|
|⚡ **Uranus**|Révolution et innovation|
|🌊 **Neptune**|Rêve et spiritualité|
|🖤 **Pluton**|Transformation et pouvoir|