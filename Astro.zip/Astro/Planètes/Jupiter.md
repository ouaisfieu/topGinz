### 🌟 **Jupiter** – L’Expansion, la Sagesse et la Chance

**Mots-clés** : [[Croissance]], [[Opportunités]], [[Sagesse]], [[Foi]], [[Abondance]], [[Optimisme]], [[Voyages]], [[Apprentissage]]

---

### 🔹 **Caractéristiques générales**

Jupiter est la planète de **l’expansion**, de la **chance** et de la **connaissance supérieure**. Il représente la quête de sens, la **spiritualité**, les **croyances** et le besoin d’explorer de nouveaux horizons. Il est associé à la **chance, à la prospérité et à l’ambition bienveillante**.

- **Élément** : Feu 🔥
- **Domicile** : [[Sagittaire]] ♐ et [[Poissons]] ♓
- **Exaltation** : [[Cancer]] ♋
- **Exil** : [[Gémeaux]] ♊ et [[Vierge]] ♍
- **Chute** : [[Capricorne]] ♑
- **Cycle** : 12 ans (reste environ 1 an par signe)

---

### 🌟 **Jupiter en Signe**

Le signe où se trouve Jupiter indique **comment nous cherchons à grandir, à apprendre et à nous épanouir**.

- **[[Jupiter en Bélier]]** → Expansion par l’initiative et l’audace
- **[[Jupiter en Taureau]]** → Croissance lente mais stable, matérialisme
- **[[Jupiter en Gémeaux]]** → Curiosité, besoin de diversité dans l’apprentissage
- **[[Jupiter en Cancer]]** → Expansion par l’émotion et l’attachement familial
- **[[Jupiter en Lion]]** → Grande confiance en soi, succès flamboyant
- **[[Jupiter en Vierge]]** → Apprentissage structuré, sens du détail
- **[[Jupiter en Balance]]** → Croissance par les relations et la diplomatie
- **[[Jupiter en Scorpion]]** → Transformation et recherche de vérité
- **[[Jupiter en Sagittaire]]** → Expansion naturelle, besoin d’explorer
- **[[Jupiter en Capricorne]]** → Réussite grâce à la discipline
- **[[Jupiter en Verseau]]** → Vision humanitaire, expansion intellectuelle
- **[[Jupiter en Poissons]]** → Foi profonde, idéalisme, connexion spirituelle

---

### 🏠 **Jupiter en Maison**

La maison où se trouve Jupiter montre **le domaine où nous avons de la chance, où nous pouvons nous épanouir et évoluer**.

- **[[Jupiter en Maison 1]]** → Optimisme naturel, charisme
- **[[Jupiter en Maison 2]]** → Abondance matérielle, chance financière
- **[[Jupiter en Maison 3]]** → Communication fluide, amour du savoir
- **[[Jupiter en Maison 4]]** → Expansion dans le foyer et les racines
- **[[Jupiter en Maison 5]]** → Créativité épanouie, amour du plaisir
- **[[Jupiter en Maison 6]]** → Épanouissement par le travail et la santé
- **[[Jupiter en Maison 7]]** → Chance dans les relations et partenariats
- **[[Jupiter en Maison 8]]** → Succès dans les transformations profondes
- **[[Jupiter en Maison 9]]** → Voyages et apprentissages enrichissants
- **[[Jupiter en Maison 10]]** → Réussite sociale et professionnelle
- **[[Jupiter en Maison 11]]** → Expansion par les groupes et réseaux
- **[[Jupiter en Maison 12]]** → Protection spirituelle, sagesse intérieure

---

### ⚡ **Aspects de Jupiter**

Les aspects de Jupiter influencent **notre optimisme, notre chance et notre manière d’élargir nos horizons**.

- **Conjonction** → Amplification (_ex : [[Jupiter conjoint Soleil]] = charisme fort_)
- **Trigone/Sextile** → Croissance fluide (_ex : [[Jupiter trigone Vénus]] = chance en amour_)
- **Carré/Opposition** → Excès ou exagération (_ex : [[Jupiter carré Mercure]] = bavardage excessif_)

---

🌟 **Jupiter est la planète de l’expansion et de la découverte. Il nous pousse à grandir, à apprendre et à croire en la vie.**