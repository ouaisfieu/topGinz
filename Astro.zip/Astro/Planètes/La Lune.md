### 🌙 **La Lune** – L’Inconscient, les Émotions et l’Intuition

**Mots-clés** : [[Émotions]], [[Intuition]], [[Mémoire]], [[Réceptivité]], [[Imagination]], [[Besoin de sécurité]], [[Subconscient]], [[Féminin sacré]]

---

#### 🔹 **Caractéristiques générales**

La Lune représente **le monde intérieur**, les émotions et les réactions instinctives. Elle symbolise **la sensibilité, la mémoire et les besoins profonds**, souvent inconscients. Associée au féminin, à l’enfance et aux souvenirs, elle illustre **notre manière de ressentir et de réagir face au monde**.

- **Élément** : Eau 💧
- **Domicile** : [[Cancer]] ♋
- **Exaltation** : [[Taureau]] ♉
- **Exil** : [[Capricorne]] ♑
- **Chute** : [[Scorpion]] ♏
- **Cycle** : 28 jours (elle traverse un signe en environ 2,5 jours)

#### 🌙 **La Lune en Signe**

Le signe où se trouve la Lune révèle **notre sensibilité émotionnelle, nos besoins affectifs et notre manière de gérer nos humeurs**.

- [[Lune en Bélier]] → Émotions impulsives, besoin d’action
- [[Lune en Taureau]] → Stabilité émotionnelle, besoin de sécurité
- [[Lune en Gémeaux]] → Esprit vif, besoin de communication
- [[Lune en Cancer]] → Hyper-sensibilité, attachement au passé
- [[Lune en Lion]] → Besoin de reconnaissance affective
- [[Lune en Vierge]] → Émotions maîtrisées, analyse des ressentis
- [[Lune en Balance]] → Besoin d’harmonie émotionnelle
- [[Lune en Scorpion]] → Intense, émotions profondes et secrètes
- [[Lune en Sagittaire]] → Besoin de liberté émotionnelle
- [[Lune en Capricorne]] → Contrôle des émotions, retenue affective
- [[Lune en Verseau]] → Détachement émotionnel, indépendance
- [[Lune en Poissons]] → Sensibilité extrême, réceptivité intuitive

#### 🏠 **La Lune en Maison**

La maison où se trouve la Lune indique **le domaine de vie où l’on recherche sécurité et réconfort émotionnel**.

- [[Lune en Maison 1]] → Sensibilité visible, humeur changeante
- [[Lune en Maison 2]] → Sécurité émotionnelle liée aux biens matériels
- [[Lune en Maison 3]] → Esprit curieux, communication émotionnelle
- [[Lune en Maison 4]] → Importance du foyer et des racines
- [[Lune en Maison 5]] → Expression émotionnelle créative
- [[Lune en Maison 6]] → Besoin de routine pour l’équilibre émotionnel
- [[Lune en Maison 7]] → Émotions influencées par les relations
- [[Lune en Maison 8]] → Transformations émotionnelles intenses
- [[Lune en Maison 9]] → Besoin d’évasion émotionnelle
- [[Lune en Maison 10]] → Vie publique influencée par les émotions
- [[Lune en Maison 11]] → Attachement au collectif et aux amitiés
- [[Lune en Maison 12]] → Monde émotionnel caché, intuition puissante

#### ⚡ **Aspects de la Lune**

Les aspects de la Lune influencent notre manière d’exprimer nos émotions et d’interagir avec notre environnement.

- **Conjonction** → Amplification ([[Lune conjointe Neptune]] = intuition extrême)
- **Trigone/Sextile** → Harmonie ([[Lune trigone Vénus]] = douceur affective)
- **Carré/Opposition** → Tensions ([[Lune carré Mars]] = émotions explosives)

---

La Lune est **le miroir de notre monde intérieur**, reflétant nos besoins affectifs, nos instincts et nos mémoires profondes. 🌙✨