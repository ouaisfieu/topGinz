### 🌞 **Le Soleil** – L'Essence et la Conscience de Soi

**Mots-clés** : [[Identité]], [[Volonté]], [[Créativité]], [[Conscience]], [[Égo]], [[Vitalité]], [[Expression]]

#### 🔹 **Caractéristiques générales**

Le Soleil représente le **cœur du thème astral**. Il symbolise l’**identité profonde**, la **volonté de s’exprimer** et la **quête de soi**. Associé à l’énergie du jour et à la lumière, il éclaire notre chemin de vie et révèle **notre essence véritable**.

- **Élément** : Feu 🔥
- **Domicile** : [[Lion]] ♌
- **Exaltation** : [[Bélier]] ♈
- **Exil** : [[Verseau]] ♒
- **Chute** : [[Balance]] ♎
- **Cycle** : 1 an (il traverse un signe du zodiaque chaque mois)

#### 🌞 **Le Soleil en Signe**

Le signe où se trouve le Soleil définit **notre personnalité fondamentale** et la manière dont nous affirmons notre individualité.

- [[Soleil en Bélier]] → Impulsif, dynamique, leader naturel
- [[Soleil en Taureau]] → Stable, persévérant, ancré
- [[Soleil en Gémeaux]] → Communicatif, curieux, adaptable
- [[Soleil en Cancer]] → Sensible, protecteur, intuitif
- [[Soleil en Lion]] → Charismatique, créatif, confiant
- [[Soleil en Vierge]] → Précis, réfléchi, méthodique
- [[Soleil en Balance]] → Diplômate, harmonieux, sociable
- [[Soleil en Scorpion]] → Intense, mystérieux, transformateur
- [[Soleil en Sagittaire]] → Optimiste, philosophe, aventurier
- [[Soleil en Capricorne]] → Responsable, ambitieux, discipliné
- [[Soleil en Verseau]] → Visionnaire, indépendant, anticonformiste
- [[Soleil en Poissons]] → Empathique, inspiré, rêveur

#### 🏠 **Le Soleil en Maison**

La maison où se trouve le Soleil indique **le domaine de vie où nous brillons naturellement** et où nous cherchons à nous affirmer.

- [[Soleil en Maison 1]] → Forte personnalité, leadership affirmé
- [[Soleil en Maison 2]] → Importance des valeurs, de la sécurité matérielle
- [[Soleil en Maison 3]] → Expression, communication, curiosité
- [[Soleil en Maison 4]] → Ancrage familial, quête de sécurité
- [[Soleil en Maison 5]] → Créativité, joie de vivre, enfants
- [[Soleil en Maison 6]] → Travail, discipline, santé
- [[Soleil en Maison 7]] → Importance des relations, du couple
- [[Soleil en Maison 8]] → Transformations profondes, mysticisme
- [[Soleil en Maison 9]] → Philosophie, voyages, expansion mentale
- [[Soleil en Maison 10]] → Carrière, reconnaissance sociale
- [[Soleil en Maison 11]] → Collectif, amitiés, engagement social
- [[Soleil en Maison 12]] → Spiritualité, intériorité, isolement

#### ⚡ **Aspects du Soleil**

Les aspects entre le Soleil et d’autres planètes influencent **la manière dont notre identité s’exprime**.

- **Conjonction** → Fusion des énergies ([[Soleil conjoint Mars]] = volonté affirmée)
- **Trigone/Sextile** → Facilité, harmonie ([[Soleil trigone Jupiter]] = optimisme naturel)
- **Carré/Opposition** → Tensions, défis ([[Soleil carré Saturne]] = sentiment de restriction)

---

Le Soleil est **le noyau de notre existence**, la force qui nous pousse à rayonner et à incarner pleinement qui nous sommes. 🔆