### 🔥 **Mars** – L'Action, la Volonté et le Désir

**Mots-clés** : [[Énergie]], [[Volonté]], [[Dynamisme]], [[Désir]], [[Affirmation de soi]], [[Conflit]], [[Ambition]], [[Passion]]

---

### 🔹 **Caractéristiques générales**

Mars est la planète de **l’action**, de la **combativité** et de la **volonté**. Il représente la manière dont nous prenons des initiatives, notre capacité à **agir, lutter et désirer**. Il est aussi lié à la sexualité et à l’instinct de survie.

- **Élément** : Feu 🔥
- **Domicile** : [[Bélier]] ♈ et [[Scorpion]] ♏
- **Exaltation** : [[Capricorne]] ♑
- **Exil** : [[Balance]] ♎ et [[Taureau]] ♉
- **Chute** : [[Cancer]] ♋
- **Cycle** : Environ 2 ans (il reste environ 6 semaines par signe)

---

### 🔥 **Mars en Signe**

Le signe où se trouve Mars révèle notre **style d’action, notre manière de gérer les conflits et notre rapport au désir**.

- **[[Mars en Bélier]]** → Action impulsive, forte volonté
- **[[Mars en Taureau]]** → Persévérance, résistance à l’effort
- **[[Mars en Gémeaux]]** → Énergie dispersée, grande adaptabilité
- **[[Mars en Cancer]]** → Actions influencées par l’émotion
- **[[Mars en Lion]]** → Ambition, leadership naturel
- **[[Mars en Vierge]]** → Efficacité, précision dans l’action
- **[[Mars en Balance]]** → Diplomatie dans les conflits, charme actif
- **[[Mars en Scorpion]]** → Intensité, détermination extrême
- **[[Mars en Sagittaire]]** → Enthousiasme, besoin d’aventure
- **[[Mars en Capricorne]]** → Discipline, stratégie dans l’action
- **[[Mars en Verseau]]** → Rébellion, actions imprévisibles
- **[[Mars en Poissons]]** → Énergie fluctuante, motivation inspirée

---

### 🏠 **Mars en Maison**

La maison où se trouve Mars indique **le domaine où nous mettons le plus d’énergie et où nous pouvons rencontrer des défis**.

- **[[Mars en Maison 1]]** → Forte personnalité, combativité
- **[[Mars en Maison 2]]** → Énergie investie dans les finances et les possessions
- **[[Mars en Maison 3]]** → Communication vive, débat intense
- **[[Mars en Maison 4]]** → Conflits familiaux, besoin d’un foyer dynamique
- **[[Mars en Maison 5]]** → Passion dans la créativité et les amours
- **[[Mars en Maison 6]]** → Travail intense, exigence physique
- **[[Mars en Maison 7]]** → Relations dynamiques, attirance pour les défis
- **[[Mars en Maison 8]]** → Transformations profondes, sexualité intense
- **[[Mars en Maison 9]]** → Soif de découvertes et d’expériences
- **[[Mars en Maison 10]]** → Ambition professionnelle, leadership
- **[[Mars en Maison 11]]** → Engagement social, actions collectives
- **[[Mars en Maison 12]]** → Combats intérieurs, force cachée

---

### ⚡ **Aspects de Mars**

Les aspects de Mars influencent **notre dynamisme, notre manière d’agir et de réagir**.

- **Conjonction** → Intensité (_ex : [[Mars conjoint Soleil]] = volonté affirmée_)
- **Trigone/Sextile** → Énergie fluide (_ex : [[Mars trigone Jupiter]] = optimisme actif_)
- **Carré/Opposition** → Tensions et conflits (_ex : [[Mars carré Saturne]] = blocages dans l’action_)

---

🔥 **Mars est notre moteur d’action et notre force de volonté. Il nous pousse à avancer, à lutter et à nous affirmer.**