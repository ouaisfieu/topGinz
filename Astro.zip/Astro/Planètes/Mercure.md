## 🟠 **Mercure** – L'Intellect, la Communication et l'Adaptabilité

**Mots-clés** : [[Esprit]], [[Communication]], [[Curiosité]], [[Intelligence]], [[Adaptabilité]], [[Apprentissage]], [[Expression]], [[Mobilité]]

---

### 🔹 **Caractéristiques générales**

Mercure est la planète de l’**intellect**, de la **pensée rationnelle** et de la **communication**. Il régit la manière dont nous **analysons**, **transmettons** et **recevons** les informations. Il est aussi lié aux déplacements, aux échanges et à l’apprentissage.

- **Élément** : Neutre (Air & Terre) 🌬️🌱
- **Domicile** : [[Gémeaux]] ♊ et [[Vierge]] ♍
- **Exaltation** : [[Vierge]] ♍
- **Exil** : [[Sagittaire]] ♐ et [[Poissons]] ♓
- **Chute** : [[Poissons]] ♓
- **Cycle** : Environ 88 jours (traverse un signe en 2 à 3 semaines, sauf en rétrograde)

---

### 🟠 **Mercure en Signe**

Le signe où se trouve Mercure détermine notre **style de pensée**, notre **logique** et notre **façon de communiquer**.

- **[[Mercure en Bélier]]** → Esprit vif, communication directe
- **[[Mercure en Taureau]]** → Pensée lente mais pragmatique
- **[[Mercure en Gémeaux]]** → Curiosité insatiable, communication rapide
- **[[Mercure en Cancer]]** → Pensée intuitive, mémoire forte
- **[[Mercure en Lion]]** → Communication théâtrale et persuasive
- **[[Mercure en Vierge]]** → Pensée analytique, précision
- **[[Mercure en Balance]]** → Diplomatie, raisonnement équilibré
- **[[Mercure en Scorpion]]** → Esprit pénétrant, goût pour le mystère
- **[[Mercure en Sagittaire]]** → Esprit philosophique, spontanéité verbale
- **[[Mercure en Capricorne]]** → Pensée structurée, pragmatisme
- **[[Mercure en Verseau]]** → Esprit innovant, pensée visionnaire
- **[[Mercure en Poissons]]** → Pensée intuitive, communication floue

---

### 🏠 **Mercure en Maison**

La maison où se trouve Mercure montre **le domaine de vie où l’on applique notre intelligence et nos compétences en communication**.

- **[[Mercure en Maison 1]]** → Identité influencée par l'intellect
- **[[Mercure en Maison 2]]** → Pensée axée sur les finances et les valeurs
- **[[Mercure en Maison 3]]** → Facilité d'apprentissage et communication fluide
- **[[Mercure en Maison 4]]** → Pensée influencée par l’éducation et la famille
- **[[Mercure en Maison 5]]** → Expression créative et ludique
- **[[Mercure en Maison 6]]** → Esprit méthodique, importance du travail
- **[[Mercure en Maison 7]]** → Communication essentielle dans les relations
- **[[Mercure en Maison 8]]** → Intellect profond, intérêt pour l'occulte
- **[[Mercure en Maison 9]]** → Esprit ouvert, intérêt pour la philosophie et les voyages
- **[[Mercure en Maison 10]]** → Communication influente dans la carrière
- **[[Mercure en Maison 11]]** → Esprit novateur, influence sur les groupes
- **[[Mercure en Maison 12]]** → Pensée introspective, intuition forte

---

### ⚡ **Aspects de Mercure**

Les aspects entre Mercure et d’autres planètes influencent la **manière dont nous pensons et communiquons**.

- **Conjonction** → Fusion d'énergies (_ex : [[Mercure conjoint Uranus]] = pensée originale_)
- **Trigone/Sextile** → Fluidité (_ex : [[Mercure trigone Jupiter]] = pensée optimiste_)
- **Carré/Opposition** → Tensions intellectuelles (_ex : [[Mercure carré Saturne]] = rigidité mentale_)

---

🟠 **Mercure est la clé de notre intelligence, de notre parole et de notre capacité à nous adapter aux situations.**