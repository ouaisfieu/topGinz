### 🌊 **Neptune en Signe**

Le signe où se trouve Neptune révèle **notre manière d’accéder à l’inspiration, à la spiritualité et aux illusions**.

- **[[Neptune en Bélier]]** → Spiritualité combative, idéaux révolutionnaires
- **[[Neptune en Taureau]]** → Sensualité mystique, recherche d’extase matérielle
- **[[Neptune en Gémeaux]]** → Esprit inspiré, tendance à la dispersion mentale
- **[[Neptune en Cancer]]** → Rêve de famille idéale, grande émotivité
- **[[Neptune en Lion]]** → Inspiration créative, illusion du pouvoir
- **[[Neptune en Vierge]]** → Spiritualité pragmatique, quête de perfection
- **[[Neptune en Balance]]** → Illusions relationnelles, amour idéalisé
- **[[Neptune en Scorpion]]** → Mysticisme profond, attraction pour l’occulte
- **[[Neptune en Sagittaire]]** → Vision spirituelle élargie, foi sans limites
- **[[Neptune en Capricorne]]** → Spiritualité structurée, illusion du succès
- **[[Neptune en Verseau]]** → Rêve collectif, humanisme utopique
- **[[Neptune en Poissons]]** → Sensibilité extrême, connexion mystique totale

---

### 🏠 **Neptune en Maison**

La maison où se trouve Neptune montre **le domaine où nous sommes inspirés mais aussi vulnérables aux illusions**.

- **[[Neptune en Maison 1]]** → Personnalité énigmatique, charisme magnétique
- **[[Neptune en Maison 2]]** → Confusion financière, inspiration dans la gestion des ressources
- **[[Neptune en Maison 3]]** → Esprit intuitif, communication floue
- **[[Neptune en Maison 4]]** → Atmosphère familiale floue, attachement aux racines spirituelles
- **[[Neptune en Maison 5]]** → Créativité débordante, amours idéalisés
- **[[Neptune en Maison 6]]** → Sensibilité aux maladies, travail inspiré mais chaotique
- **[[Neptune en Maison 7]]** → Illusions en amour, forte empathie relationnelle
- **[[Neptune en Maison 8]]** → Mystère profond, expériences occultes
- **[[Neptune en Maison 9]]** → Spiritualité et voyages intérieurs, foi profonde
- **[[Neptune en Maison 10]]** → Carrière artistique ou spirituelle, flou professionnel
- **[[Neptune en Maison 11]]** → Idéaux collectifs, utopies sociales
- **[[Neptune en Maison 12]]** → Mysticisme profond, vulnérabilité psychique

---

### ⚡ **Aspects de Neptune**

Les aspects de Neptune influencent **notre perception de la réalité, notre imagination et notre spiritualité**.

- **Conjonction** → Inspiration extrême ou confusion (_ex : [[Neptune conjoint Soleil]] = personnalité mystique_)
- **Trigone/Sextile** → Créativité fluide (_ex : [[Neptune trigone Lune]] = grande sensibilité intuitive_)
- **Carré/Opposition** → Désillusion ou fuite (_ex : [[Neptune carré Mercure]] = pensée confuse, mensonges possibles_)

---

🌊 **Neptune est la planète de l’intuition et des mondes invisibles. Il nous pousse à rêver et à nous connecter au divin, mais peut aussi nous perdre dans l’illusion.**