### 🖤 **Pluton** – La Transformation, le Pouvoir et la Renaissance

**Mots-clés** : [[Transformation]], [[Pouvoir]], [[Renaissance]], [[Destruction]], [[Mystère]], [[Psychologie profonde]], [[Ombre]], [[Résilience]]

---

### 🔹 **Caractéristiques générales**

Pluton est la planète des **transformations profondes**, du **renouveau** et des **crises nécessaires**. Il représente **le pouvoir caché, l’ombre psychologique et la destruction suivie de reconstruction**. Pluton agit en profondeur, souvent de manière invisible, mais son influence est **intense et irréversible**. Il est associé aux **peurs, aux instincts refoulés et à la régénération**.

- **Élément** : Eau 💧
- **Domicile** : [[Scorpion]] ♏
- **Exaltation** : [[Bélier]] ♈ (selon certaines écoles)
- **Exil** : [[Taureau]] ♉
- **Chute** : [[Balance]] ♎
- **Cycle** : 248 ans (reste entre 12 et 31 ans par signe)

---

### 🖤 **Pluton en Signe**

Le signe où se trouve Pluton influence **la manière dont nous vivons les transformations profondes et la quête de pouvoir**.

- **[[Pluton en Bélier]]** → Transformation par l’action, révolution intérieure
- **[[Pluton en Taureau]]** → Pouvoir sur la matière, attachement aux ressources
- **[[Pluton en Gémeaux]]** → Métamorphose mentale, communication intense
- **[[Pluton en Cancer]]** → Régénération émotionnelle, attachement au passé
- **[[Pluton en Lion]]** → Transformation de l’ego, besoin de reconnaissance
- **[[Pluton en Vierge]]** → Métamorphose par l’analyse et le perfectionnisme
- **[[Pluton en Balance]]** → Crises relationnelles, quête d’équilibre profond
- **[[Pluton en Scorpion]]** → Transformation totale, intensité et pouvoir caché
- **[[Pluton en Sagittaire]]** → Mutation des croyances, expansion intérieure
- **[[Pluton en Capricorne]]** → Déconstruction des structures, pouvoir hiérarchique
- **[[Pluton en Verseau]]** → Révolution collective, destruction des normes sociales
- **[[Pluton en Poissons]]** → Dissolution totale de l’ego, quête spirituelle profonde

---

### 🏠 **Pluton en Maison**

La maison où se trouve Pluton montre **le domaine où nous vivons des transformations intenses et où nous devons affronter nos ombres**.

- **[[Pluton en Maison 1]]** → Personnalité magnétique, force intérieure
- **[[Pluton en Maison 2]]** → Pouvoir sur les finances, crise matérielle
- **[[Pluton en Maison 3]]** → Pensée obsessionnelle, pouvoir des mots
- **[[Pluton en Maison 4]]** → Transformations familiales, ancrage profond
- **[[Pluton en Maison 5]]** → Expression intense, créativité cathartique
- **[[Pluton en Maison 6]]** → Régénération par le travail et la santé
- **[[Pluton en Maison 7]]** → Relations intenses, attirance pour le pouvoir
- **[[Pluton en Maison 8]]** → Métamorphoses radicales, mystères et sexualité
- **[[Pluton en Maison 9]]** → Transformation des croyances, quête initiatique
- **[[Pluton en Maison 10]]** → Pouvoir social et professionnel, ascension marquée
- **[[Pluton en Maison 11]]** → Réseaux puissants, influence sur le collectif
- **[[Pluton en Maison 12]]** → Ombres inconscientes profondes, renaissance spirituelle

---

### ⚡ **Aspects de Pluton**

Les aspects de Pluton influencent **notre rapport au pouvoir, à la transformation et aux crises existentielles**.

- **Conjonction** → Fusion d’intensité (_ex : [[Pluton conjoint Soleil]] = puissance intérieure énorme_)
- **Trigone/Sextile** → Transformation maîtrisée (_ex : [[Pluton trigone Vénus]] = magnétisme naturel en amour_)
- **Carré/Opposition** → Crises profondes et tensions (_ex : [[Pluton carré Lune]] = peurs inconscientes intenses_)

---

🖤 **Pluton est la planète des profondeurs et du pouvoir caché. Il nous pousse à renaître de nos cendres et à embrasser la transformation.**