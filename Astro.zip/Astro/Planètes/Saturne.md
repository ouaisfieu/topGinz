### ⏳ **Saturne** – La Discipline, la Responsabilité et les Limites

**Mots-clés** : [[Structure]], [[Responsabilité]], [[Discipline]], [[Temps]], [[Ambition]], [[Maturité]], [[Épreuves]], [[Patience]]

---

### 🔹 **Caractéristiques générales**

Saturne est la planète de la **discipline, des limitations et de l’apprentissage par l’effort**. Il représente **les règles, la rigueur et le sens des responsabilités**. Il est souvent associé aux **épreuves**, mais celles-ci servent à structurer et solidifier notre existence. Il incarne aussi le **temps, la patience et la sagesse acquise avec l’expérience**.

- **Élément** : Terre 🌱
- **Domicile** : [[Capricorne]] ♑ et [[Verseau]] ♒
- **Exaltation** : [[Balance]] ♎
- **Exil** : [[Cancer]] ♋ et [[Lion]] ♌
- **Chute** : [[Bélier]] ♈
- **Cycle** : 29 ans (reste environ 2,5 ans par signe)

---

### ⏳ **Saturne en Signe**

Le signe où se trouve Saturne indique **dans quel domaine nous devons faire preuve de rigueur et d’endurance pour atteindre la réussite**.

- **[[Saturne en Bélier]]** → Défis dans l’affirmation de soi, apprentissage du leadership
- **[[Saturne en Taureau]]** → Blocages matériels, apprentissage de la stabilité
- **[[Saturne en Gémeaux]]** → Communication contrôlée, structuration du savoir
- **[[Saturne en Cancer]]** → Émotions retenues, besoin de sécurité intérieure
- **[[Saturne en Lion]]** → Responsabilité dans l’expression de soi, recherche de reconnaissance
- **[[Saturne en Vierge]]** → Exigence extrême, perfectionnisme
- **[[Saturne en Balance]]** → Épreuves relationnelles, structuration des partenariats
- **[[Saturne en Scorpion]]** → Transformation difficile, maîtrise des pulsions
- **[[Saturne en Sagittaire]]** → Limitations dans les croyances, discipline dans l’apprentissage
- **[[Saturne en Capricorne]]** → Ambition structurée, succès par l’effort
- **[[Saturne en Verseau]]** → Défis dans l’innovation, apprentissage de l’indépendance
- **[[Saturne en Poissons]]** → Confrontation aux illusions, discipline spirituelle

---

### 🏠 **Saturne en Maison**

La maison où se trouve Saturne indique **le domaine où nous devons travailler dur et faire preuve de patience pour réussir**.

- **[[Saturne en Maison 1]]** → Maturité précoce, responsabilité personnelle
- **[[Saturne en Maison 2]]** → Blocages financiers, nécessité de bâtir avec le temps
- **[[Saturne en Maison 3]]** → Communication mesurée, pensée structurée
- **[[Saturne en Maison 4]]** → Responsabilités familiales, quête de stabilité intérieure
- **[[Saturne en Maison 5]]** → Peur de s’exprimer, créativité disciplinée
- **[[Saturne en Maison 6]]** → Rigueur au travail, attention à la santé
- **[[Saturne en Maison 7]]** → Relations sérieuses, engagement tardif
- **[[Saturne en Maison 8]]** → Transformation intérieure lente, maîtrise des peurs
- **[[Saturne en Maison 9]]** → Apprentissages rigoureux, vision du monde structurée
- **[[Saturne en Maison 10]]** → Réussite professionnelle lente mais solide
- **[[Saturne en Maison 11]]** → Sélection rigoureuse des amitiés et réseaux
- **[[Saturne en Maison 12]]** → Confrontation aux peurs inconscientes, solitude constructive

---

### ⚡ **Aspects de Saturne**

Les aspects de Saturne influencent **notre rapport à la discipline, aux limites et à l’effort**.

- **Conjonction** → Rigidité ou structuration (_ex : [[Saturne conjoint Soleil]] = personnalité sérieuse_)
- **Trigone/Sextile** → Équilibre dans l’effort (_ex : [[Saturne trigone Mercure]] = pensée disciplinée_)
- **Carré/Opposition** → Défis et restrictions (_ex : [[Saturne carré Lune]] = difficulté à exprimer ses émotions_)

---

⏳ **Saturne est le maître du temps et de la responsabilité. Il nous enseigne la patience, l’endurance et la construction solide.**