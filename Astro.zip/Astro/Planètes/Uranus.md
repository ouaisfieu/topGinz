### ⚡ **Uranus** – Le Changement, l'Innovation et la Rébellion

**Mots-clés** : [[Indépendance]], [[Révolution]], [[Innovation]], [[Inattendu]], [[Génie]], [[Progrès]], [[Liberté]], [[Originalité]]

---

### 🔹 **Caractéristiques générales**

Uranus est la planète du **changement soudain, de l’innovation et de la rébellion**. Elle représente la manière dont nous remettons en question l’ordre établi et cherchons à nous libérer des contraintes. C’est la planète de la **créativité visionnaire**, du **progrès technologique** et des **idées révolutionnaires**. Elle pousse à sortir des sentiers battus et à briser les normes.

- **Élément** : Air 🌬️
- **Domicile** : [[Verseau]] ♒
- **Exaltation** : [[Scorpion]] ♏
- **Exil** : [[Lion]] ♌
- **Chute** : [[Taureau]] ♉
- **Cycle** : 84 ans (reste environ 7 ans par signe)

---

### ⚡ **Uranus en Signe**

Le signe où se trouve Uranus révèle **comment nous exprimons notre besoin de liberté et d’innovation**.

- **[[Uranus en Bélier]]** → Révolution impulsive, leader innovant
- **[[Uranus en Taureau]]** → Innovation matérielle, résistance au changement
- **[[Uranus en Gémeaux]]** → Pensée éclatée, communication révolutionnaire
- **[[Uranus en Cancer]]** → Révolution émotionnelle, besoin d'indépendance familiale
- **[[Uranus en Lion]]** → Créativité radicale, expression unique
- **[[Uranus en Vierge]]** → Innovation dans les méthodes et la santé
- **[[Uranus en Balance]]** → Changement dans les relations et la justice
- **[[Uranus en Scorpion]]** → Transformation radicale, intensité réformatrice
- **[[Uranus en Sagittaire]]** → Exploration libre, révolution philosophique
- **[[Uranus en Capricorne]]** → Changement structurel, innovation dans la tradition
- **[[Uranus en Verseau]]** → Génie collectif, esprit futuriste
- **[[Uranus en Poissons]]** → Intuition révolutionnaire, spiritualité alternative

---

### 🏠 **Uranus en Maison**

La maison où se trouve Uranus indique **le domaine où nous expérimentons des changements soudains et des idées novatrices**.

- **[[Uranus en Maison 1]]** → Personnalité unique, besoin d'indépendance
- **[[Uranus en Maison 2]]** → Instabilité financière, innovations économiques
- **[[Uranus en Maison 3]]** → Communication originale, esprit visionnaire
- **[[Uranus en Maison 4]]** → Changements soudains dans le foyer
- **[[Uranus en Maison 5]]** → Créativité décalée, amour non conventionnel
- **[[Uranus en Maison 6]]** → Approche originale du travail et de la santé
- **[[Uranus en Maison 7]]** → Relations instables, attrait pour l’inhabituel
- **[[Uranus en Maison 8]]** → Transformations soudaines, crises libératrices
- **[[Uranus en Maison 9]]** → Voyages imprévus, croyances révolutionnaires
- **[[Uranus en Maison 10]]** → Carrière innovante, destin imprévisible
- **[[Uranus en Maison 11]]** → Réseau social original, idées progressistes
- **[[Uranus en Maison 12]]** → Révolutions inconscientes, intuition fulgurante

---

### ⚡ **Aspects d'Uranus**

Les aspects d’Uranus influencent **notre rapport à l’innovation, aux changements et à la rébellion**.

- **Conjonction** → Génie ou chaos (_ex : [[Uranus conjoint Soleil]] = personnalité excentrique_)
- **Trigone/Sextile** → Créativité fluide (_ex : [[Uranus trigone Mercure]] = idées avant-gardistes_)
- **Carré/Opposition** → Instabilité (_ex : [[Uranus carré Mars]] = impulsivité incontrôlable_)

---

⚡ **Uranus est la planète des éclairs de génie et des bouleversements nécessaires. Il nous pousse à nous libérer et à embrasser le changement.**