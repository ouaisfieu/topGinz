### 💖 **Vénus** – L'Amour, l'Harmonie et les Valeurs

**Mots-clés** : [[Amour]], [[Relations]], [[Beauté]], [[Harmonie]], [[Valeurs]], [[Plaisir]], [[Créativité]], [[Séduction]]

---

### 🔹 **Caractéristiques générales**

Vénus est la planète de **l’amour, des plaisirs et de l’esthétique**. Elle représente notre manière d’aimer, nos valeurs et ce qui nous attire. Elle régit aussi les arts, la sensualité et l’équilibre dans nos relations.

- **Élément** : Air 🌬️ et Terre 🌱
- **Domicile** : [[Taureau]] ♉ et [[Balance]] ♎
- **Exaltation** : [[Poissons]] ♓
- **Exil** : [[Scorpion]] ♏ et [[Bélier]] ♈
- **Chute** : [[Vierge]] ♍
- **Cycle** : 225 jours (traverse un signe en 3 à 4 semaines, sauf en rétrograde)

---

### 💖 **Vénus en Signe**

Le signe où se trouve Vénus définit notre **style amoureux, nos goûts et notre rapport au plaisir**.

- **[[Vénus en Bélier]]** → Passion immédiate, amour spontané
- **[[Vénus en Taureau]]** → Sensualité, amour stable et fidèle
- **[[Vénus en Gémeaux]]** → Légèreté, besoin de stimulation intellectuelle
- **[[Vénus en Cancer]]** → Affectivité profonde, besoin de sécurité
- **[[Vénus en Lion]]** → Charisme, amour théâtral et intense
- **[[Vénus en Vierge]]** → Amour discret, fidélité et pragmatisme
- **[[Vénus en Balance]]** → Harmonie relationnelle, élégance naturelle
- **[[Vénus en Scorpion]]** → Passion intense, émotions profondes
- **[[Vénus en Sagittaire]]** → Aventure sentimentale, besoin de liberté
- **[[Vénus en Capricorne]]** → Amour sérieux, engagement durable
- **[[Vénus en Verseau]]** → Indépendance amoureuse, originalité
- **[[Vénus en Poissons]]** → Amour idéaliste, romantisme extrême

---

### 🏠 **Vénus en Maison**

La maison où se trouve Vénus indique **le domaine de vie où nous recherchons l’harmonie, le plaisir et la beauté**.

- **[[Vénus en Maison 1]]** → Charme naturel, séduction spontanée
- **[[Vénus en Maison 2]]** → Amour des plaisirs matériels, talents artistiques
- **[[Vénus en Maison 3]]** → Communication douce et charme intellectuel
- **[[Vénus en Maison 4]]** → Harmonie dans le foyer, attachement familial
- **[[Vénus en Maison 5]]** → Créativité, amour du jeu et du flirt
- **[[Vénus en Maison 6]]** → Esthétique dans le travail, amour du détail
- **[[Vénus en Maison 7]]** → Relations équilibrées, besoin de partenariat
- **[[Vénus en Maison 8]]** → Attirance pour la transformation et l’intensité
- **[[Vénus en Maison 9]]** → Amour de la culture, des voyages et de la philosophie
- **[[Vénus en Maison 10]]** → Charisme professionnel, quête de reconnaissance
- **[[Vénus en Maison 11]]** → Relations sociales harmonieuses, amitiés précieuses
- **[[Vénus en Maison 12]]** → Amour caché, romantisme secret et idéalisme

---

### ⚡ **Aspects de Vénus**

Les aspects de Vénus influencent **la manière dont nous aimons et apprécions la beauté**.

- **Conjonction** → Fusion d’énergies (_ex : [[Vénus conjointe Mars]] = désir puissant_)
- **Trigone/Sextile** → Facilité en amour (_ex : [[Vénus trigone Jupiter]] = chance affective_)
- **Carré/Opposition** → Défis relationnels (_ex : [[Vénus carré Saturne]] = peur de l’engagement_)

---

💖 **Vénus nous guide dans nos relations, notre façon d’aimer et ce qui nous rend heureux.**