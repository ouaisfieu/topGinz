### ♈ **Les Signes Astrologiques Occidentaux – Introduction**

L’**astrologie occidentale** repose sur **12 signes du zodiaque**, chacun associé à une période de l’année et à des traits de personnalité spécifiques. Chaque signe est lié à **un élément**, **une modalité** et **une planète maîtresse**, influençant profondément la manière dont il s’exprime.

Chaque signe représente une **énergie fondamentale**, et son influence est modifiée par sa position dans un **thème astral**.

---

## 🔥 **Les 12 Signes du Zodiaque et leurs Caractéristiques**

|♈ **Signe**|🔥 **Élément**|⏳ **Modalité**|🌟 **Planète Maîtresse**|🎭 **Mots-Clés**|
|---|---|---|---|---|
|**[[Bélier]]** ♈|Feu 🔥|Cardinal ⚡|[[Mars]] 🛡️|[[Action]], [[Dynamisme]], [[Impulsivité]]|
|**[[Taureau]]** ♉|Terre 🌱|Fixe 🏛️|[[Vénus]] 💖|[[Stabilité]], [[Confort]], [[Endurance]]|
|**[[Gémeaux]]** ♊|Air 🌬️|Mutable 🔄|[[Mercure]] 🟠|[[Curiosité]], [[Communication]], [[Adaptabilité]]|
|**[[Cancer]]** ♋|Eau 💧|Cardinal ⚡|[[Astro/Planètes/La Lune]] 🌙|[[Émotion]], [[Intuition]], [[Protection]]|
|**[[Lion]]** ♌|Feu 🔥|Fixe 🏛️|[[Le Soleil]] ☀️|[[Charisme]], [[Créativité]], [[Fierté]]|
|**[[Vierge]]** ♍|Terre 🌱|Mutable 🔄|[[Mercure]] 🟠|[[Analyse]], [[Organisation]], [[Précision]]|
|**[[Balance]]** ♎|Air 🌬️|Cardinal ⚡|[[Vénus]] 💖|[[Équilibre]], [[Relationnel]], [[Harmonie]]|
|**[[Scorpion]]** ♏|Eau 💧|Fixe 🏛️|[[Pluton]] 🖤 (trad. [[Mars]])|[[Mystère]], [[Intensité]], [[Transformation]]|
|**[[Sagittaire]]** ♐|Feu 🔥|Mutable 🔄|[[Jupiter]] 🌟|[[Exploration]], [[Optimisme]], [[Liberté]]|
|**[[Capricorne]]** ♑|Terre 🌱|Cardinal ⚡|[[Saturne]] ⏳|[[Ambition]], [[Discipline]], [[Responsabilité]]|
|**[[Verseau]]** ♒|Air 🌬️|Fixe 🏛️|[[Uranus]] ⚡ (trad. [[Saturne]])|[[Rébellion]], [[Innovation]], [[Indépendance]]|
|**[[Poissons]]** ♓|Eau 💧|Mutable 🔄|[[Neptune]] 🌊 (trad. [[Jupiter]])|[[Sensibilité]], [[Intuition]], [[Imagination]]|

---

## **Explication des Composantes d’un Signe**

### **1️⃣ L’élément – L’énergie fondamentale du signe**

Chaque signe appartient à **l’un des quatre éléments**, qui influencent **sa manière d’agir et de percevoir le monde** :

- **🔥 Feu** → Passion, spontanéité, énergie → [[Bélier]], [[Lion]], [[Sagittaire]]
- **🌱 Terre** → Stabilité, pragmatisme, matérialisme → [[Taureau]], [[Vierge]], [[Capricorne]]
- **🌬️ Air** → Communication, intellect, sociabilité → [[Gémeaux]], [[Balance]], [[Verseau]]
- **💧 Eau** → Émotions, intuition, sensibilité → [[Cancer]], [[Scorpion]], [[Poissons]]

---

### **2️⃣ La Modalité – La façon dont le signe interagit avec le monde**

Les signes sont aussi classés en **trois modalités**, qui indiquent **comment ils expriment leur énergie**.

- **⚡ Cardinaux** → Initient, impulsent le mouvement → [[Bélier]], [[Cancer]], [[Balance]], [[Capricorne]]
- **🏛️ Fixes** → Stabilisent, construisent et persistent → [[Taureau]], [[Lion]], [[Scorpion]], [[Verseau]]
- **🔄 Mutables** → Adaptent, transforment, s’ajustent → [[Gémeaux]], [[Vierge]], [[Sagittaire]], [[Poissons]]

---

### **3️⃣ La Planète Maîtresse – L’essence du signe**

Chaque signe est gouverné par une **planète maîtresse**, qui **teinte son énergie** :

- **[[Mars]]** → Action et combat → [[Bélier]]
- **[[Vénus]]** → Amour et plaisir → [[Taureau]], [[Balance]]
- **[[Mercure]]** → Intelligence et communication → [[Gémeaux]], [[Vierge]]
- **[[Astro/Planètes/La Lune]]** → Émotions et intuition → [[Cancer]]
- **[[Le Soleil]]** → Charisme et affirmation de soi → [[Lion]]
- **[[Pluton]]** → Transformation et intensité → [[Scorpion]]
- **[[Jupiter]]** → Expansion et sagesse → [[Sagittaire]]
- **[[Saturne]]** → Discipline et rigueur → [[Capricorne]]
- **[[Uranus]]** → Rébellion et innovation → [[Verseau]]
- **[[Neptune]]** → Rêve et spiritualité → [[Poissons]]

---

## 🔥 **Début de l’Exploration des Signes – Le Bélier ♈**

Nous allons maintenant **explorer chaque signe individuellement**, en détaillant :

- **Ses caractéristiques principales**
- **Son influence en amour, au travail, en amitié**
- **Son expression selon les planètes et les maisons**