### ♋ **Cancer** – L’Émotion et la Protection

**Mots-clés** : [[Émotion]], [[Intuition]], [[Sensibilité]], [[Protection]], [[Famille]], [[Imagination]], [[Attachement]], [[Nostalgie]]

---

## 💧 **Caractéristiques Générales du Cancer**

Le **Cancer** est le **quatrième signe du zodiaque**, symbolisant **l’émotion, la sécurité et l’attachement aux racines**. C’est un signe d’**Eau** 💧 et de **modalité cardinale** ⚡, ce qui le rend **profondément intuitif, protecteur et attaché à ses valeurs familiales et émotionnelles**.

### 📌 **Fiche d’Identité du Cancer**

- **Date** : 21 juin – 22 juillet
- **Élément** : [[EAU]] 💧 (émotions, imagination, réceptivité)
- **Modalité** : [[Cardinal]] ⚡ (initiation, action intuitive)
- **Planète Maîtresse** : [[Astro/Planètes/La Lune]] 🌙 (émotions, inconscient, protection)
- **Exaltation** : [[Jupiter]] 🌟 (expansion émotionnelle, bienveillance)
- **Exil** : [[Saturne]] ⏳ (difficulté avec la rigueur et le détachement)
- **Chute** : [[Mars]] 🛡️ (énergie passive, évite les conflits)

---

## 🏠 **Personnalité du Cancer**

Le Cancer est un **signe profondément émotif**, doté d’une **intuition puissante** et d’un **fort attachement aux souvenirs et aux traditions**. Il cherche **la sécurité, le confort et des relations sincères**.

### ✅ **Ses Qualités**

✔️ **Empathique et bienveillant** → Il ressent les émotions des autres et apporte du réconfort  
✔️ **Intuitif et inspiré** → Il perçoit les choses au-delà du rationnel  
✔️ **Protecteur et fidèle** → Il veille sur ses proches avec tendresse  
✔️ **Créatif et imaginatif** → Il excelle dans les arts et la narration  
✔️ **Patient et persévérant** → Il sait attendre le bon moment pour agir

### ❌ **Ses Défis**

❌ **Hypersensible** → Il peut se laisser submerger par ses émotions  
❌ **Rancunier** → Il n’oublie pas facilement les blessures du passé  
❌ **Lunatique** → Son humeur change en fonction de son ressenti  
❌ **Fuyant face aux conflits** → Il préfère se replier sur lui-même  
❌ **Trop attaché au passé** → Il a du mal à lâcher prise et à avancer

---

## ❤️ **Le Cancer en Amour**

Le Cancer est un **partenaire tendre et attentionné**, qui recherche une **relation stable et fusionnelle**. Il a besoin de **sécurité émotionnelle** et d’un **partenaire capable de le rassurer et de comprendre sa sensibilité**.

### 💕 **Comment il aime ?**

- **Affectueux et dévoué** : Il se donne entièrement à son couple
- **Besoin d’engagement** : Il recherche une relation profonde et durable
- **Fusionnel mais protecteur** : Il veut être un refuge pour son partenaire
- **Très émotif** : Ses sentiments sont intenses et sincères

### 💘 **Compatibilité amoureuse**

💞 **Meilleurs matchs** : [[Taureau]] ♉, [[Vierge]] ♍, [[Scorpion]] ♏, [[Poissons]] ♓  
💔 **Défis avec** : [[Bélier]] ♈, [[Balance]] ♎, [[Capricorne]] ♑

---

## 💼 **Le Cancer au Travail**

Le Cancer **travaille avec cœur** et excelle dans les **métiers où l’émotion et l’intuition ont une place importante**. Il aime les environnements **familiaux, protecteurs et inspirants**.

### 🚀 **Ses points forts**

✔️ **Grande imagination** → Talent pour la création et la narration  
✔️ **Empathie et écoute** → Excellente capacité à comprendre autrui  
✔️ **Persévérant et travailleur** → Il ne lâche rien lorsqu’il croit en une cause

### 🛠️ **Ses métiers idéaux**

- Psychologue ou thérapeute 🧠💙
- Écrivain ou poète 📖✨
- Restaurateur ou chef cuisinier 🍲
- Professeur ou éducateur 📚
- Historien ou archiviste 🏛️

---

## 👫 **Le Cancer en Amitié**

Le Cancer est un **ami loyal et attentionné**, qui entretient des **liens profonds et sincères** avec son entourage.

✔️ **Soutien émotionnel infaillible**  
✔️ **Sensible et attentif aux besoins des autres**  
✔️ **Généreux, il se donne sans compter pour ses proches**  
❌ **Parfois trop protecteur et collant**  
❌ **Peut se replier sur lui-même lors de périodes de doute**

---

## 🏠 **Le Cancer en Maison**

La maison où se trouve le Cancer dans un thème astral indique **le domaine où l’on ressent un fort besoin de sécurité et de lien émotionnel**.

- **[[Cancer en Maison 1]]** → Personnalité douce et intuitive
- **[[Cancer en Maison 2]]** → Besoin de stabilité financière pour se sentir en sécurité
- **[[Cancer en Maison 3]]** → Communication émotionnelle et sensible
- **[[Cancer en Maison 4]]** → Attachement profond au foyer et aux racines
- **[[Cancer en Maison 5]]** → Créativité inspirée par l’émotion
- **[[Cancer en Maison 6]]** → Travail basé sur l’aide et le soin aux autres
- **[[Cancer en Maison 7]]** → Recherche d’un partenaire stable et protecteur
- **[[Cancer en Maison 8]]** → Sensibilité face aux grandes transformations de la vie
- **[[Cancer en Maison 9]]** → Croyances influencées par l’histoire et les traditions
- **[[Cancer en Maison 10]]** → Carrière influencée par l’émotion et le besoin de protection
- **[[Cancer en Maison 11]]** → Amitiés sincères et protectrices
- **[[Cancer en Maison 12]]** → Forte connexion avec l’inconscient et le monde spirituel

---

## ⚡ **Le Cancer et les Planètes**

Les planètes en Cancer modifient leur expression en y ajoutant **une énergie protectrice et intuitive** :

- **[[Soleil en Cancer]]** → Identité sensible et familiale
- **[[Lune en Cancer]]** → Émotions profondes, grande intuition
- **[[Mercure en Cancer]]** → Communication basée sur l’émotion
- **[[Vénus en Cancer]]** → Amour tendre, besoin de sécurité affective
- **[[Mars en Cancer]]** → Actions guidées par l’émotion
- **[[Jupiter en Cancer]]** → Expansion à travers le bien-être et la famille
- **[[Saturne en Cancer]]** → Difficulté à exprimer les émotions
- **[[Uranus en Cancer]]** → Changements soudains dans les attaches émotionnelles
- **[[Neptune en Cancer]]** → Rêverie et imagination débordante
- **[[Pluton en Cancer]]** → Transformations émotionnelles profondes

---

💧 **Le Cancer est un signe de sensibilité, de protection et d’attachement. Il cherche un refuge émotionnel stable et sécurisant, tout en nourrissant ceux qu’il aime avec une infinie tendresse**