### ♑ **Capricorne** – L’Ambition et la Discipline

**Mots-clés** : [[Ambition]], [[Responsabilité]], [[Discipline]], [[Persévérance]], [[Rigueur]], [[Succès]], [[Patience]], [[Pragmatisme]]

---

## ⏳ **Caractéristiques Générales du Capricorne**

Le **Capricorne** est le **dixième signe du zodiaque**, symbolisant **la rigueur, l’endurance et l’ascension vers le succès**. C’est un signe de **Terre** 🌱 et de **modalité cardinale** ⚡, ce qui lui confère **une grande capacité de structuration, une ambition inébranlable et une approche pragmatique de la vie**.

### 📌 **Fiche d’Identité du Capricorne**

- **Date** : 22 décembre – 19 janvier
- **Élément** : [[Terre]] 🌱 (réalisme, stabilité, matérialisme)
- **Modalité** : [[Cardinal]] ⚡ (initiative, leadership)
- **Planète Maîtresse** : [[Saturne]] ⏳ (discipline, structure, temps)
- **Exaltation** : [[Mars]] 🛡️ (travail acharné et endurance)
- **Exil** : [[Astro/Planètes/La Lune]] 🌙 (difficulté à exprimer ses émotions)
- **Chute** : [[Jupiter]] 🌟 (réserve face à l’expansion et à l’optimisme)

---

## 🏔️ **Personnalité du Capricorne**

Le Capricorne est **réservé, méthodique et endurant**. Il se fixe **des objectifs ambitieux** et fait preuve **d’une patience exceptionnelle** pour les atteindre. **Réaliste et structuré**, il croit en la valeur du travail et de la discipline.

### ✅ **Ses Qualités**

✔️ **Déterminé et persévérant** → Il ne recule devant aucun défi  
✔️ **Sérieux et fiable** → On peut compter sur lui dans toutes les situations  
✔️ **Organisé et méthodique** → Il planifie tout pour assurer son succès  
✔️ **Pragmatique et réaliste** → Il base ses décisions sur les faits  
✔️ **Ambitieux et travailleur** → Il vise toujours plus haut

### ❌ **Ses Défis**

❌ **Trop sérieux et austère** → Il peut manquer de légèreté et de spontanéité  
❌ **Distant et réservé** → Il a du mal à exprimer ses émotions  
❌ **Exigeant et strict** → Il peut être dur envers lui-même et les autres  
❌ **Matérialiste et carriériste** → Il accorde une grande importance au statut social  
❌ **Pessimiste** → Il a tendance à voir le verre à moitié vide

---

## ❤️ **Le Capricorne en Amour**

Le Capricorne est un **partenaire stable et loyal**, qui prend **l’amour très au sérieux**. Il met du temps à s’engager, mais lorsqu’il le fait, c’est pour **du solide**.

### 💕 **Comment il aime ?**

- **Prudent et réservé** : Il ne se livre pas facilement
- **Loyal et engagé** : Il construit des relations durables
- **Montre son amour par des actes** : Il prouve ses sentiments par des gestes concrets
- **Besoin de stabilité** : Il veut une relation solide et fiable

### 💘 **Compatibilité amoureuse**

💞 **Meilleurs matchs** : [[Taureau]] ♉, [[Vierge]] ♍, [[Scorpion]] ♏, [[Poissons]] ♓  
💔 **Défis avec** : [[Bélier]] ♈, [[Gémeaux]] ♊, [[Sagittaire]] ♐

---

## 💼 **Le Capricorne au Travail**

Le Capricorne **excelle dans les environnements structurés**, où il peut **gravir les échelons grâce à son travail et sa discipline**.

### 🚀 **Ses points forts**

✔️ **Travailleur infatigable** → Il est prêt à tout pour atteindre ses objectifs  
✔️ **Planificateur hors pair** → Il sait organiser et structurer efficacement  
✔️ **Fiable et responsable** → On peut lui confier des responsabilités importantes

### 🛠️ **Ses métiers idéaux**

- Directeur d’entreprise ou manager 🏢
- Ingénieur ou architecte 🏗️
- Politicien ou juge ⚖️
- Médecin ou scientifique 🔬
- Banquier ou financier 📈

---

## 👫 **Le Capricorne en Amitié**

Le Capricorne est **un ami fiable et loyal**, mais **sélectif dans ses relations**. Il préfère **la qualité à la quantité** et **ne donne sa confiance qu’aux personnes qui l’ont méritée**.

✔️ **Soutien indéfectible pour ses vrais amis**  
✔️ **Donne des conseils sages et réfléchis**  
✔️ **Encourage ses proches à se dépasser**  
❌ **Peut être froid et distant au premier abord**  
❌ **Manque parfois de légèreté et d’humour**

---

## 🏠 **Le Capricorne en Maison**

La maison où se trouve le Capricorne dans un thème astral indique **le domaine où l’on cherche à bâtir, à structurer et à atteindre le succès**.

- **[[Capricorne en Maison 1]]** → Personnalité disciplinée et ambitieuse
- **[[Capricorne en Maison 2]]** → Gestion rigoureuse des finances
- **[[Capricorne en Maison 3]]** → Communication sérieuse et réfléchie
- **[[Capricorne en Maison 4]]** → Attachement profond aux traditions familiales
- **[[Capricorne en Maison 5]]** → Expression créative structurée
- **[[Capricorne en Maison 6]]** → Travail acharné et rigueur dans la santé
- **[[Capricorne en Maison 7]]** → Relations engagées et matures
- **[[Capricorne en Maison 8]]** → Transformations lentes mais profondes
- **[[Capricorne en Maison 9]]** → Études longues et approfondies
- **[[Capricorne en Maison 10]]** → Réussite sociale et professionnelle
- **[[Capricorne en Maison 11]]** → Amitiés sélectives et influentes
- **[[Capricorne en Maison 12]]** → Recherche spirituelle disciplinée

---

## ⚡ **Le Capricorne et les Planètes**

Les planètes en Capricorne modifient leur expression en y ajoutant **une énergie structurante et ambitieuse** :

- **[[Soleil en Capricorne]]** → Identité disciplinée et persévérante
- **[[Lune en Capricorne]]** → Émotions contrôlées, besoin de sécurité
- **[[Mercure en Capricorne]]** → Esprit logique et pragmatique
- **[[Vénus en Capricorne]]** → Amour sérieux et basé sur l’engagement
- **[[Mars en Capricorne]]** → Énergie maîtrisée et efficacité au travail
- **[[Jupiter en Capricorne]]** → Expansion lente mais solide
- **[[Saturne en Capricorne]]** → Discipline extrême et succès par l’effort
- **[[Uranus en Capricorne]]** → Innovation structurée et vision long terme
- **[[Neptune en Capricorne]]** → Spiritualité ancrée dans le concret
- **[[Pluton en Capricorne]]** → Transformation à travers le pouvoir et l’ambition

---

⏳ **Le Capricorne est un signe de construction, de discipline et de réussite. Il avance lentement mais sûrement vers ses objectifs, prêt à gravir chaque sommet avec patience et détermination.**