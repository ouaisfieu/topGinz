### 🐓 **Coq** – La Précision et la Persévérance

**Mots-clés** : [[Précision]], [[Persévérance]], [[Discipline]], [[Fierté]], [[Organisation]], [[Charisme]], [[Franc-parler]], [[Dévouement]]

---

## 🎤 **Caractéristiques Générales du Coq**

Le **Coq** est le **dixième animal du zodiaque chinois**, symbolisant **la rigueur, la droiture et l’esprit de perfection**. Il est **persévérant, fier et méthodique**, avançant avec **détermination vers ses objectifs**.

### 📌 **Fiche d’Identité du Coq**

- **Années de naissance** : 1969, 1981, 1993, 2005, 2017, 2029, 2041
- **Élément fixe** : [[Métal]] ⚔️ (rigueur, force, détermination)
- **Polarité** : [[Yin]] ☯ (introspection, maîtrise, endurance)
- **Saison associée** : Automne 🍂
- **Trigramme** : ☰ Ciel et autorité

---

## 🏆 **Personnalité du Coq**

Le Coq est **ambitieux, persévérant et organisé**. Il possède un **grand sens du détail et du perfectionnisme**, ce qui peut le rendre **exigeant envers lui-même et les autres**. Il est **franc et direct**, n’hésitant pas à **exprimer son opinion avec assurance**.

### ✅ **Ses Qualités**

✔️ **Travailleur et persévérant** → Rien ne l’arrête lorsqu’il a un objectif  
✔️ **Honnête et direct** → Il dit ce qu’il pense sans détour  
✔️ **Organisé et méthodique** → Il planifie tout avec soin  
✔️ **Confiant et charismatique** → Il sait se mettre en avant  
✔️ **Fidèle et responsable** → Il prend ses engagements au sérieux

### ❌ **Ses Défis**

❌ **Trop exigeant et perfectionniste** → Peut manquer de flexibilité  
❌ **Franc au point d’être blessant** → Il manque parfois de tact  
❌ **Aime avoir raison** → Il peut être rigide dans ses opinions  
❌ **Besoin de reconnaissance** → Il cherche souvent l’admiration des autres  
❌ **Méfiant et critique** → Il analyse tout et peut être sceptique

---

## ❤️ **Le Coq en Amour**

Le Coq est **loyal et protecteur en amour**, mais il a besoin d’un partenaire qui **respecte son besoin d’ordre et d’organisation**. Il apprécie **les relations solides et bien construites**.

### 💕 **Comment il aime ?**

- **Sérieux et fidèle** : Il cherche une relation stable
- **Protecteur et impliqué** : Il veille sur son partenaire
- **Direct et honnête** : Il ne supporte pas les faux-semblants
- **Peut être rigide** : Il aime que les choses soient à sa manière

### 💘 **Compatibilité amoureuse**

💞 **Meilleurs matchs** : [[Buffle]] 🐂, [[Dragon]] 🐉, [[Serpent]] 🐍  
💔 **Défis avec** : [[Lapin]] 🐇, [[Cheval]] 🐎, [[Rat]] 🐀

---

## 💼 **Le Coq au Travail**

Le Coq excelle dans **les métiers demandant rigueur, organisation et précision**. Il aime **les postes où il peut structurer et diriger**.

### 🚀 **Ses points forts**

✔️ **Efficace et discipliné** → Il accomplit ses tâches avec sérieux  
✔️ **Fiable et perfectionniste** → Il vise toujours l’excellence  
✔️ **Bon gestionnaire** → Il sait organiser et structurer

### 🛠️ **Ses métiers idéaux**

- Ingénieur ou architecte 🏗️
- Militaire ou policier 🛡️
- Chirurgien ou médecin 🏥
- Professeur ou formateur 📚
- Chef d’entreprise ou manager 💼

---

## 👫 **Le Coq en Amitié**

Le Coq est **un ami loyal et fiable**, mais il peut être **un peu trop critique**.

✔️ **Toujours présent pour soutenir ses proches**  
✔️ **Offre des conseils honnêtes et directs**  
✔️ **Aime débattre et partager ses idées**  
❌ **Peut être trop franc et manquer de tact**  
❌ **A du mal à accepter les erreurs des autres**

---

## 🏮 **Les Différents Types de Coq Selon les Éléments**

Chaque année du Coq est influencée par **un des cinq éléments**, modifiant son expression et sa personnalité :

|🌿 **Élément**|📅 **Années**|🌟 **Traits spécifiques**|
|---|---|---|
|**[[Coq de Bois]]** 🌳|1945, 2005, 2065|Créatif, réfléchi, plus flexible|
|**[[Coq de Feu]]** 🔥|1957, 2017, 2077|Charismatique, autoritaire, dynamique|
|**[[Coq de Terre]]** 🌍|1909, 1969, 2029|Organisé, pragmatique, plus patient|
|**[[Coq de Métal]]** ⚔️|1921, 1981, 2041|Rigoriste, ambitieux, intransigeant|
|**[[Coq d’Eau]]** 💧|1933, 1993, 2053|Intuitif, communicatif, adaptable|

---

## 🎭 **Le Coq et les Autres Signes du Zodiaque Chinois**

Le Coq interagit différemment avec chaque signe :

- 🐂 **Avec le [[Buffle]]** → Relation stable et basée sur la rigueur
- 🐉 **Avec le [[Dragon]]** → Connexion forte et admiration mutuelle
- 🐍 **Avec le [[Serpent]]** → Complémentarité et respect
- 🐇 **Avec le [[Lapin]]** → Visions du monde trop différentes
- 🐎 **Avec le [[Cheval]]** → Conflits entre ordre et liberté
- 🐀 **Avec le [[Rat]]** → Relation tendue par la critique et l’exigence

---

## 📜 **Conclusion**

🐓 **Le Coq est un perfectionniste, fier de son travail et de ses idées. Son charisme et sa discipline lui permettent d’atteindre des sommets, mais il doit apprendre à être plus souple avec les autres.**