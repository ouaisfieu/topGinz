### ♓ **Poissons** – L’Intuition et la Spiritualité

**Mots-clés** : [[Sensibilité]], [[Intuition]], [[Spiritualité]], [[Rêve]], [[Émotion]], [[Compassion]], [[Imagination]], [[Mysticisme]]

---

## 🌊 **Caractéristiques Générales des Poissons**

Le **Poissons** est le **douzième et dernier signe du zodiaque**, symbolisant **l’infini, l’universalité et la connexion spirituelle**. C’est un signe d’**Eau** 💧 et de **modalité mutable** 🔄, ce qui lui confère **une grande sensibilité, une profonde imagination et une capacité à capter les émotions et énergies invisibles**.

### 📌 **Fiche d’Identité des Poissons**

- **Date** : 19 février – 20 mars
- **Élément** : [[EAU]] 💧 (émotion, intuition, inconscient)
- **Modalité** : [[Mutable]] 🔄 (adaptabilité, fluidité)
- **Planète Maîtresse** : [[Neptune]] 🌊 (rêve, illusion, spiritualité) et [[Jupiter]] 🌟 (expansion mystique)
- **Exaltation** : [[Vénus]] 💖 (amour universel, compassion)
- **Exil** : [[Mercure]] 🟠 (pensée floue, difficulté à structurer ses idées)
- **Chute** : [[Saturne]] ⏳ (manque de limites et de structure)

---

## 🐠 **Personnalité des Poissons**

Le Poissons est **émotif, rêveur et profondément connecté à l’invisible**. Il possède une **grande empathie et une imagination débordante**, ce qui peut le rendre **inspirant, mais aussi vulnérable aux illusions et aux influences extérieures**.

### ✅ **Ses Qualités**

✔️ **Intuitif et spirituel** → Il capte les énergies et les émotions  
✔️ **Créatif et rêveur** → Il a un monde intérieur riche et inspirant  
✔️ **Compatissant et altruiste** → Il ressent et comprend la souffrance des autres  
✔️ **Flexible et adaptable** → Il sait s’ajuster aux situations et aux personnes  
✔️ **Mystique et profond** → Il est attiré par les mystères de l’univers

### ❌ **Ses Défis**

❌ **Trop sensible et perméable** → Il absorbe les émotions des autres et peut se sentir submergé  
❌ **Manque de réalisme** → Il a parfois du mal à distinguer rêve et réalité  
❌ **Fuyant et indécis** → Il évite les conflits et préfère se réfugier dans son imaginaire  
❌ **Dépendant émotionnellement** → Il a besoin de connexions profondes mais peut être influençable  
❌ **Tendance à l’évasion** → Peut fuir la réalité via les addictions ou l’idéalisme excessif

---

## ❤️ **Le Poissons en Amour**

Le Poissons vit l’amour **de manière romantique et fusionnelle**. Il cherche une **relation spirituelle et émotionnelle intense**, où il peut **se perdre et s’abandonner totalement**.

### 💕 **Comment il aime ?**

- **Idéaliste et rêveur** : Il imagine un amour parfait
- **Empathique et tendre** : Il se met à la place de l’autre
- **Fusionnel et passionné** : Il a besoin d’une connexion profonde
- **Parfois insaisissable** : Il peut sembler distant ou perdu dans ses pensées

### 💘 **Compatibilité amoureuse**

💞 **Meilleurs matchs** : [[Cancer]] ♋, [[Scorpion]] ♏, [[Taureau]] ♉, [[Capricorne]] ♑  
💔 **Défis avec** : [[Gémeaux]] ♊, [[Sagittaire]] ♐, [[Vierge]] ♍

---

## 💼 **Le Poissons au Travail**

Le Poissons excelle dans **les domaines artistiques, spirituels et sociaux**. Il a besoin **d’inspiration et de sens dans son travail**, et supporte mal **les environnements trop rigides**.

### 🚀 **Ses points forts**

✔️ **Grande imagination et créativité** → Il excelle dans l’art et la narration  
✔️ **Empathie et écoute** → Il sait comprendre et aider les autres  
✔️ **Adaptabilité et intuition** → Il sent les tendances avant qu’elles ne se manifestent

### 🛠️ **Ses métiers idéaux**

- Artiste, musicien ou écrivain 🎭🎨
- Thérapeute ou guérisseur 🧘‍♂️
- Cinéaste ou photographe 🎥
- Prêtre, astrologue ou médium 🔮
- Soignant, infirmier ou travailleur humanitaire 🤲

---

## 👫 **Le Poissons en Amitié**

Le Poissons est **un ami fidèle et compatissant**, qui **écoute et comprend sans juger**.

✔️ **Toujours prêt à aider et à soutenir**  
✔️ **Sensible aux émotions des autres**  
✔️ **Peut créer des liens profonds et spirituels**  
❌ **Parfois difficile à suivre ou insaisissable**  
❌ **Peut se perdre dans des relations toxiques par excès de compassion**

---

## 🏠 **Le Poissons en Maison**

La maison où se trouve le Poissons dans un thème astral indique **le domaine où l’on ressent le besoin d’évasion, d’intuition et de connexion spirituelle**.

- **[[Poissons en Maison 1]]** → Personnalité rêveuse et mystique
- **[[Poissons en Maison 2]]** → Rapport flou à l’argent et aux possessions
- **[[Poissons en Maison 3]]** → Communication inspirée mais parfois vague
- **[[Poissons en Maison 4]]** → Foyer empreint de spiritualité et de mystère
- **[[Poissons en Maison 5]]** → Créativité débordante, amours romantiques
- **[[Poissons en Maison 6]]** → Sensibilité aux environnements de travail
- **[[Poissons en Maison 7]]** → Partenaire idéaliste et fusionnel
- **[[Poissons en Maison 8]]** → Transformations spirituelles profondes
- **[[Poissons en Maison 9]]** → Voyage intérieur, quête spirituelle
- **[[Poissons en Maison 10]]** → Carrière artistique ou humanitaire
- **[[Poissons en Maison 11]]** → Amitiés spirituelles et intuitives
- **[[Poissons en Maison 12]]** → Connexion forte avec l’inconscient et l’invisible

---

## ⚡ **Le Poissons et les Planètes**

Les planètes en Poissons modifient leur expression en y ajoutant **une touche d’intuition, de rêve et de sensibilité mystique** :

- **[[Soleil en Poissons]]** → Identité douce et spirituelle
- **[[Lune en Poissons]]** → Émotions profondes et hypersensibilité
- **[[Mercure en Poissons]]** → Pensée intuitive mais peu structurée
- **[[Vénus en Poissons]]** → Amour romantique et inconditionnel
- **[[Mars en Poissons]]** → Actions guidées par l’émotion et l’inspiration
- **[[Jupiter en Poissons]]** → Expansion dans la spiritualité et la compassion
- **[[Saturne en Poissons]]** → Structuration de l’inconscient et du mysticisme
- **[[Uranus en Poissons]]** → Inspiration révolutionnaire et vision prophétique
- **[[Neptune en Poissons]]** → Imagination infinie et connexion au divin
- **[[Pluton en Poissons]]** → Transformation spirituelle et dissolution de l’ego