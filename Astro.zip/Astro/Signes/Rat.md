### 🐀 **Rat** – L’Intelligence et l’Ambition

**Mots-clés** : [[Intelligence]], [[Charme]], [[Ambition]], [[Ruse]], [[Persévérance]], [[Économie]], [[Curiosité]], [[Stratégie]]

---

## 🏆 **Caractéristiques Générales du Rat**

Le **Rat** est le **premier animal du zodiaque chinois**, symbolisant **l’intelligence, la ruse et la capacité à s’adapter**. Il est **rapide, débrouillard et doté d’un fort sens de l’opportunité**. Son esprit vif **lui permet de trouver des solutions astucieuses et de tirer parti des situations avec habileté**.

### 📌 **Fiche d’Identité du Rat**

- **Années de naissance** : 1960, 1972, 1984, 1996, 2008, 2020, 2032
- **Élément fixe** : [[EAU]] 💧 (intelligence, intuition, fluidité)
- **Polarité** : [[Yang]] ☯ (action, dynamisme, expansion)
- **Saison associée** : Hiver ❄️
- **Trigramme** : ☵ Eau profonde

---

## 🧠 **Personnalité du Rat**

Le Rat est **intelligent, charismatique et stratège**. Il excelle **dans l’analyse et la planification**, trouvant toujours une issue même dans les situations complexes. Il est **curieux et ambitieux**, ce qui le pousse **à accumuler connaissances et richesses**.

### ✅ **Ses Qualités**

✔️ **Astucieux et débrouillard** → Il sait toujours comment s’en sortir  
✔️ **Charismatique et sociable** → Il attire naturellement les gens  
✔️ **Ambitieux et stratège** → Il vise le succès et sait s’organiser  
✔️ **Économe et prudent** → Il gère bien ses ressources  
✔️ **Rapide et adaptable** → Il s’ajuste aux nouvelles situations

### ❌ **Ses Défis**

❌ **Manipulateur et calculateur** → Peut user de ruses pour atteindre ses objectifs  
❌ **Anxieux et stressé** → Son esprit toujours en alerte peut l’épuiser  
❌ **Trop prudent** → Il peut hésiter à prendre des risques nécessaires  
❌ **Possessif** → Il n’aime pas partager ce qu’il a durement acquis  
❌ **Tendance au surmenage** → Peut en faire trop pour réussir

---

## ❤️ **Le Rat en Amour**

Le Rat est **charmant et séducteur**, mais il aime **garder une part de mystère**. Il cherche **un partenaire intelligent et indépendant**, avec qui il pourra **échanger des idées et construire une vie stable**.

### 💕 **Comment il aime ?**

- **Séducteur et joueur** : Il sait charmer avec finesse
- **Prudent et observateur** : Il analyse son partenaire avant de s’engager
- **Loyal mais indépendant** : Il tient à son espace personnel
- **Peut être jaloux** : Il protège ce qu’il considère comme sien

### 💘 **Compatibilité amoureuse**

💞 **Meilleurs matchs** : [[Dragon]] 🐉, [[Singe]] 🐒, [[Buffle]] 🐂  
💔 **Défis avec** : [[Cheval]] 🐎, [[Lapin]] 🐇, [[Coq]] 🐓

---

## 💼 **Le Rat au Travail**

Le Rat excelle dans **les métiers nécessitant stratégie, planification et intelligence rapide**. Il aime **gérer, organiser et optimiser** pour atteindre ses objectifs.

### 🚀 **Ses points forts**

✔️ **Esprit analytique** → Capable de voir les opportunités et les pièges  
✔️ **Rapide et efficace** → Il comprend vite et agit sans tarder  
✔️ **Gestionnaire avisé** → Il sait gérer les finances et les ressources

### 🛠️ **Ses métiers idéaux**

- Entrepreneur ou gestionnaire 📈
- Analyste financier ou comptable 💰
- Consultant ou stratège 🎯
- Chercheur ou inventeur 🧠
- Journaliste ou écrivain 📚

---

## 👫 **Le Rat en Amitié**

Le Rat est **un ami dynamique et curieux**, qui aime **échanger des idées et explorer de nouveaux horizons**.

✔️ **Toujours des conseils pratiques et astucieux**  
✔️ **Aime organiser des sorties et des projets**  
✔️ **Sociable mais sélectif dans ses relations**  
❌ **Peut être secret et méfiant**  
❌ **N’aime pas dépendre des autres**

---

## 🏮 **Les Différents Types de Rat Selon les Éléments**

Chaque année du Rat est influencée par **un des cinq éléments**, modifiant son expression et sa personnalité :

|🌿 **Élément**|📅 **Années**|🌟 **Traits spécifiques**|
|---|---|---|
|**[[Rat de Bois]]** 🌳|1924, 1984, 2044|Créatif, idéaliste, diplomate|
|**[[Rat de Feu]]** 🔥|1936, 1996, 2056|Ambitieux, énergique, passionné|
|**[[Rat de Terre]]** 🌍|1948, 2008, 2068|Pragmatique, patient, stratégique|
|**[[Rat de Métal]]** ⚔️|1960, 2020, 2080|Déterminé, méthodique, discipliné|
|**[[Rat d’Eau]]** 💧|1912, 1972, 2032|Intuitif, adaptable, observateur|

---

## 🎭 **Le Rat et les Autres Signes du Zodiaque Chinois**

Le Rat interagit différemment avec chaque signe :

- 🐉 **Avec le [[Dragon]]** → Alliance puissante, ambitions partagées
- 🐒 **Avec le [[Singe]]** → Esprit vif et complicité intellectuelle
- 🐂 **Avec le [[Buffle]]** → Stabilité et succès matériel
- 🐎 **Avec le [[Cheval]]** → Rivalité et manque d’accord
- 🐓 **Avec le [[Coq]]** → Différences de style, conflits possibles
- 🐖 **Avec le [[Cochon]]** → Bonne entente, mais le Rat peut être trop pragmatique

---

## 📜 **Conclusion**

🐀 **Le Rat est un stratège brillant, capable de s’adapter et de réussir dans n’importe quel domaine. Son intelligence et son ambition lui permettent de surmonter tous les obstacles.**