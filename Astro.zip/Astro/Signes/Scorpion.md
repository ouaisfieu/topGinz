### ♏ **Scorpion** – L’Intensité et la Transformation

**Mots-clés** : [[Passion]], [[Mystère]], [[Transformation]], [[Puissance]], [[Résilience]], [[Magnétisme]], [[Psychologie profonde]], [[Secret]]

---

## 🖤 **Caractéristiques Générales du Scorpion**

Le **Scorpion** est le **huitième signe du zodiaque**, symbolisant **la transformation, l’intensité et le pouvoir caché**. C’est un signe d’**Eau** 💧 et de **modalité fixe** 🏛️, ce qui lui confère une **émotivité profonde, une grande force intérieure et un goût pour les vérités cachées**.

### 📌 **Fiche d’Identité du Scorpion**

- **Date** : 23 octobre – 21 novembre
- **Élément** : [[EAU]] 💧 (émotions, intuition, profondeur)
- **Modalité** : [[Fixe]] 🏛️ (stabilité, persévérance)
- **Planète Maîtresse** : [[Pluton]] 🖤 (transformation, pouvoir, régénération) et [[Mars]] 🛡️ (combat, énergie brute)
- **Exaltation** : [[Uranus]] ⚡ (rébellion et génie caché)
- **Exil** : [[Vénus]] 💖 (difficulté à exprimer l’amour de manière légère)
- **Chute** : [[Astro/Planètes/La Lune]] 🌙 (émotions intenses, hypersensibilité cachée)

---

## 🦂 **Personnalité du Scorpion**

Le Scorpion est **profond, magnétique et passionné**. Il possède une **grande force intérieure**, qui lui permet de **renaître après chaque épreuve**. Il est **mystérieux et intense**, cherchant toujours **à aller au fond des choses**.

### ✅ **Ses Qualités**

✔️ **Puissant et résilient** → Il ne se laisse jamais abattre  
✔️ **Loyal et protecteur** → Il défend ceux qu’il aime jusqu’au bout  
✔️ **Intelligent et stratégique** → Il comprend les enjeux en profondeur  
✔️ **Passionné et magnétique** → Il dégage une aura intense et fascinante  
✔️ **Perceptif et intuitif** → Il détecte les mensonges et les intentions cachées

### ❌ **Ses Défis**

❌ **Possessif et jaloux** → Il veut un contrôle absolu en amour et en amitié  
❌ **Manipulateur** → Il sait influencer les autres sans qu’ils s’en rendent compte  
❌ **Rancunier** → Il n’oublie jamais une trahison  
❌ **Secret et mystérieux** → Il se dévoile rarement, même à ses proches  
❌ **Obsessionnel** → Il peut être excessif dans ses émotions et ses désirs

---

## ❤️ **Le Scorpion en Amour**

Le Scorpion vit l’amour **comme une fusion totale**. Il est **passionné, intense et loyal**, mais aussi **jaloux et exclusif**. Il recherche une **relation profonde et transformative**, où il peut **se livrer totalement**.

### 💕 **Comment il aime ?**

- **Profondément et intensément** : Il ne fait rien à moitié
- **Mystérieux et envoûtant** : Il séduit par son magnétisme
- **Possessif et protecteur** : Il ne tolère pas la trahison
- **Sexualité puissante** : Son désir est intense et fusionnel

### 💘 **Compatibilité amoureuse**

💞 **Meilleurs matchs** : [[Cancer]] ♋, [[Poissons]] ♓, [[Vierge]] ♍, [[Capricorne]] ♑  
💔 **Défis avec** : [[Bélier]] ♈, [[Gémeaux]] ♊, [[Lion]] ♌

---

## 💼 **Le Scorpion au Travail**

Le Scorpion excelle dans les **métiers nécessitant stratégie, persévérance et une compréhension profonde des mécanismes humains**.

### 🚀 **Ses points forts**

✔️ **Détermination et patience** → Il va jusqu’au bout de ses projets  
✔️ **Sens de l’analyse et du secret** → Il comprend les enjeux cachés  
✔️ **Grande force mentale** → Il ne recule devant aucun défi

### 🛠️ **Ses métiers idéaux**

- Psychologue ou psychanalyste 🧠
- Enquêteur ou détective 🔍
- Chirurgien ou médecin légiste 🏥
- Entrepreneur dans le domaine du mystère ou de la transformation 💼
- Stratège financier ou conseiller en gestion de crise 📈

---

## 👫 **Le Scorpion en Amitié**

Le Scorpion est un **ami loyal et puissant**, mais il choisit ses proches avec **une grande prudence**.

✔️ **Profondeur et intensité dans l’amitié**  
✔️ **Loyal et protecteur envers ceux qu’il aime**  
✔️ **Toujours prêt à soutenir dans les moments difficiles**  
❌ **Difficile à cerner et secret**  
❌ **Peut être rancunier en cas de trahison**

---

## 🏠 **Le Scorpion en Maison**

La maison où se trouve le Scorpion dans un thème astral indique **le domaine où l’on vit des transformations intenses et des expériences profondes**.

- **[[Scorpion en Maison 1]]** → Personnalité magnétique et mystérieuse
- **[[Scorpion en Maison 2]]** → Argent gagné par la persévérance et l’intensité
- **[[Scorpion en Maison 3]]** → Communication stratégique et secrète
- **[[Scorpion en Maison 4]]** → Foyer intense, passé marqué par des épreuves
- **[[Scorpion en Maison 5]]** → Amours passionnés et créativité profonde
- **[[Scorpion en Maison 6]]** → Travail exigeant, obsession du détail
- **[[Scorpion en Maison 7]]** → Relations intenses et parfois conflictuelles
- **[[Scorpion en Maison 8]]** → Transformations puissantes et attractivité pour l’occulte
- **[[Scorpion en Maison 9]]** → Croyances profondes et mysticisme
- **[[Scorpion en Maison 10]]** → Ambition cachée et réussite par la stratégie
- **[[Scorpion en Maison 11]]** → Amitiés profondes et sélectives
- **[[Scorpion en Maison 12]]** → Connexion intense avec l’inconscient et le mysticisme

---

## ⚡ **Le Scorpion et les Planètes**

Les planètes en Scorpion modifient leur expression en y ajoutant **une intensité, une profondeur et une volonté de transformation** :

- **[[Soleil en Scorpion]]** → Identité puissante et mystérieuse
- **[[Lune en Scorpion]]** → Émotions profondes et secrètes
- **[[Mercure en Scorpion]]** → Esprit stratégique et perçant
- **[[Vénus en Scorpion]]** → Amour intense, passionnel et possessif
- **[[Mars en Scorpion]]** → Énergie brute, combativité intérieure
- **[[Jupiter en Scorpion]]** → Expansion par la résilience et la transformation
- **[[Saturne en Scorpion]]** → Discipline dans la gestion du pouvoir et des crises
- **[[Uranus en Scorpion]]** → Rébellion intérieure et besoin de contrôle
- **[[Neptune en Scorpion]]** → Spiritualité profonde et magnétisme mystique
- **[[Pluton en Scorpion]]** → Transformation radicale et pouvoir caché

---

🖤 **Le Scorpion est un signe de puissance, de mystère et de renaissance. Il explore les profondeurs de l’âme et transforme les épreuves en force intérieure.**