### 📜 **Index des Éléments en Astrologie, Ésotérisme et Astrologie Chinoise**

Les **cinq éléments** en astrologie chinoise et les **quatre éléments** en astrologie occidentale sont des fondements de la compréhension des énergies universelles. Chaque élément incarne des dynamiques spécifiques qui influencent les personnalités, les relations et les cycles de la vie.

---

## 🔥 **[[Élément Feu]]** – Action et Transformation

**Mots-clés** : [[Énergie]], [[Passion]], [[Dynamisme]], [[Créativité]], [[Ambition]], [[Courage]], [[Transformation]], [[Volonté]]

### 🌌 **Astrologie Occidentale**

- **Signes du zodiaque** : [[Bélier]] ♈, [[Lion]] ♌, [[Sagittaire]] ♐
- **Symbolisme ésotérique** :
    - **Alchimie** : [[Soufre]] (volonté et transformation)
    - **Tarot** : [[Bâtons]] (initiative, force d’action)
    - **Magie** : Rituels de [[puissance]], [[courage]] et [[réalisation]]

### 🏮 **Astrologie Chinoise**

- **Signes associés** : [[Rat de Feu]], [[Buffle de Feu]], [[Tigre de Feu]], [[Lapin de Feu]], [[Dragon de Feu]], [[Serpent de Feu]], [[Cheval de Feu]], [[Chèvre de Feu]], [[Singe de Feu]], [[Coq de Feu]], [[Chien de Feu]], [[Cochon de Feu]]
- **Caractéristiques** : Passion, dynamisme, leadership, impulsivité

---

## 🌍 **[[Élément Terre]]** – Stabilité et Construction

**Mots-clés** : [[Stabilité]], [[Réalité]], [[Pragmatisme]], [[Endurance]], [[Sécurité]], [[Patience]], [[Structure]], [[Fécondité]]

### 🌌 **Astrologie Occidentale**

- **Signes du zodiaque** : [[Taureau]] ♉, [[Vierge]] ♍, [[Capricorne]] ♑
- **Symbolisme ésotérique** :
    - **Alchimie** : [[Sel]] (incarnation et fixation)
    - **Tarot** : [[Deniers]] (matérialisation, finances, stabilité)
    - **Magie** : Rituels de [[protection]], [[abondance]] et [[ancrage]]

### 🏮 **Astrologie Chinoise**

- **Signes associés** : [[Rat de Terre]], [[Buffle de Terre]], [[Tigre de Terre]], [[Lapin de Terre]], [[Dragon de Terre]], [[Serpent de Terre]], [[Cheval de Terre]], [[Chèvre de Terre]], [[Singe de Terre]], [[Coq de Terre]], [[Chien de Terre]], [[Cochon de Terre]]
- **Caractéristiques** : Endurance, pragmatisme, loyauté, matérialisme

---

## 🌬️ **[[Élément Air]]** – Intelligence et Mouvement

**Mots-clés** : [[Intellect]], [[Communication]], [[Idées]], [[Curiosité]], [[Adaptabilité]], [[Liberté]], [[Créativité]], [[Sociabilité]]

### 🌌 **Astrologie Occidentale**

- **Signes du zodiaque** : [[Gémeaux]] ♊, [[Balance]] ♎, [[Verseau]] ♒
- **Symbolisme ésotérique** :
    - **Alchimie** : [[Mercure]] (pensée, rapidité, transformation)
    - **Tarot** : [[Épées]] (intellect, communication, clarté mentale)
    - **Magie** : Rituels de [[sagesse]], [[intuition]] et [[apprentissage]]

---

## 💧 **[[Élément Eau]]** – Intuition et Émotions

**Mots-clés** : [[Sensibilité]], [[Intuition]], [[Émotions]], [[Mystère]], [[Imagination]], [[Spiritualité]], [[Rêverie]], [[Fluidité]]

### 🌌 **Astrologie Occidentale**

- **Signes du zodiaque** : [[Cancer]] ♋, [[Scorpion]] ♏, [[Poissons]] ♓
- **Symbolisme ésotérique** :
    - **Alchimie** : [[Mercure (prima materia)]] (transformation, connaissance cachée)
    - **Tarot** : [[Coupes]] (émotions, amour, réceptivité)
    - **Magie** : Rituels de [[guérison]], [[divination]] et [[intuition]]

### 🏮 **Astrologie Chinoise**

- **Signes associés** : [[Rat d’Eau]], [[Buffle d’Eau]], [[Tigre d’Eau]], [[Lapin d’Eau]], [[Dragon d’Eau]], [[Serpent d’Eau]], [[Cheval d’Eau]], [[Chèvre d’Eau]], [[Singe d’Eau]], [[Coq d’Eau]], [[Chien d’Eau]], [[Cochon d’Eau]]
- **Caractéristiques** : Sensibilité, intuition, adaptabilité, mystère

---

## ⚔️ **[[Élément Métal]]** (Astrologie Chinoise) – Discipline et Détermination

**Mots-clés** : [[Rigueur]], [[Détermination]], [[Force]], [[Discipline]], [[Loyauté]], [[Ambition]], [[Structuration]], [[Volonté]]

- **Signes associés** : [[Rat de Métal]], [[Buffle de Métal]], [[Tigre de Métal]], [[Lapin de Métal]], [[Dragon de Métal]], [[Serpent de Métal]], [[Cheval de Métal]], [[0. Capricorne-Chèvre de Métal]], [[Singe de Métal]], [[Coq de Métal]], [[Chien de Métal]], [[Cochon de Métal]]
- **Caractéristiques** : Rigueur, ambition, contrôle, force intérieure

---

## 🌳 **[[Élément Bois]]** (Astrologie Chinoise) – Croissance et Créativité

**Mots-clés** : [[Croissance]], [[Créativité]], [[Flexibilité]], [[Développement]], [[Évolution]], [[Idéalisme]], [[Altruisme]], [[Curiosité]]

- **Signes associés** : [[Rat de Bois]], [[Buffle de Bois]], [[Tigre de Bois]], [[Lapin de Bois]], [[Dragon de Bois]], [[Serpent de Bois]], [[Cheval de Bois]], [[Chèvre de Bois]], [[Singe de Bois]], [[Coq de Bois]], [[Chien de Bois]], [[Cochon de Bois]]
- **Caractéristiques** : Croissance, créativité, flexibilité, développement

---

Ce récapitulatif sert de **porte d’entrée vers une exploration approfondie** des éléments, reliant **l’astrologie occidentale, chinoise et les symboles ésotériques**.