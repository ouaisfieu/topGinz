
# Mixités choisies

Les **mixités choisies** sont des espaces ou des événements où la participation est volontairement limitée à certaines catégories de personnes, souvent en fonction de critères comme le genre, l'origine, l'orientation sexuelle, ou une expérience commune (par exemple, être victime de discrimination). Ces espaces visent à offrir un cadre sécurisé où les participant·es peuvent s'exprimer, échanger ou militer sans subir des dynamiques de domination ou de discrimination présentes dans des contextes mixtes.

### Objectifs des mixités choisies :

1. **Créer un espace sécurisé :** Permettre aux participant·es de parler librement de leurs expériences et de leurs luttes sans craindre d'être jugé·es, ignoré·es ou oppressé·es.
2. **Reconnaître et lutter contre les oppressions systémiques :** Les mixités choisies reconnaissent que certains groupes sont marginalisés dans les espaces dominants (par exemple, les femmes dans un espace majoritairement masculin, ou les personnes racisées dans un espace majoritairement blanc).
3. **Encourager la prise de parole :** Dans des espaces non mixtes, les personnes concernées ont plus de chances de s'exprimer et de proposer des solutions adaptées à leurs propres réalités.

---

### Exemples de mixités choisies :

- **Mixité non-mixte femmes :** Réunions ou événements ouverts uniquement aux femmes (cis ou trans), souvent dans des contextes féministes.
- **Mixité LGBTQIA+ :** Espaces réservés aux personnes LGBTQIA+ pour discuter de leurs luttes spécifiques.
- **Mixité racisée :** Espaces pour les personnes racisées (par exemple, Noirs, Arabes, Asiatiques, etc.) afin de discuter des enjeux liés au racisme.
- **Mixité sociale :** Espaces pour des personnes ayant une même condition sociale ou économique (par exemple, des travailleurs précaires ou des sans-abri).

---

### Critiques ou débats autour des mixités choisies :

1. **Accusations d'exclusion :** Certain·es critiquent ces espaces en disant qu'ils divisent plutôt qu'ils unissent ou qu'ils excluent des alliés potentiels.
    - **Réponse :** Les défenseur·es des mixités choisies expliquent qu'elles ne sont pas contre la mixité en général, mais qu'elles permettent aux groupes marginalisés de s'organiser ou de se ressourcer avant d'affronter des espaces mixtes.
2. **Complexité des identités :** Certaines personnes appartiennent à plusieurs catégories (par exemple, être une femme noire queer). Dans ce cas, il peut être difficile de déterminer quel type de mixité est le plus adapté.
3. **Risque d'entre-soi :** La critique est parfois que cela enferme les gens dans leurs propres luttes. Cependant, ces espaces sont souvent conçus comme des temps spécifiques dans un parcours plus large, pas comme une fin en soi.

---

### Différence avec la mixité générale :

La **mixité générale** implique que tout le monde peut participer sans distinction. Si elle peut sembler idéale, elle peut aussi reproduire les inégalités de la société, car les dynamiques de pouvoir (patriarcat, racisme, etc.) persistent même dans des espaces "ouverts à tou·tes".

En résumé, les mixités choisies ne sont pas anti-mixité générale, mais elles répondent à des besoins spécifiques dans des contextes d'oppression systémique. Elles cherchent à donner une voix et un espace aux personnes concernées pour qu'elles puissent ensuite, si elles le souhaitent, agir dans des cadres plus larges.

---

