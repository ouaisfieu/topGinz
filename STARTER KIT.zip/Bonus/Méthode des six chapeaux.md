# Méthode des six chapeaux

La **méthode des six chapeaux** d'Edward de Bono est une technique puissante pour structurer la réflexion, encourager la créativité et organiser les discussions. Si tu veux en savoir plus sur son fonctionnement ou son utilisation pratique, voici une synthèse détaillée :

---

### **Principe général**

La méthode repose sur six "chapeaux" imaginaires, chacun représentant une façon spécifique de penser. En portant ces chapeaux tour à tour, une personne ou un groupe explore un sujet sous plusieurs angles. Cela aide à éviter les blocages, les conflits inutiles ou les biais cognitifs.

---

### **Les six chapeaux et leur signification**

1. **Chapeau blanc (Neutre – Faits et données)**
    
    - **Rôle** : Se concentrer sur les faits, les données et les informations objectives.
    - **Questions clés** :
        - Quelles informations avons-nous ?
        - Quelles informations nous manquent-il ?
        - Comment pouvons-nous les obtenir ?
2. **Chapeau rouge (Émotions et intuitions)**
    
    - **Rôle** : Explorer les sentiments, les intuitions et les réactions instinctives.
    - **Questions clés** :
        - Quelles sont mes premières impressions ?
        - Comment est-ce que je ressens cette idée ?
        - Y a-t-il des réactions émotionnelles qu'on doit prendre en compte ?
3. **Chapeau noir (Critique – Risques et problèmes)**
    
    - **Rôle** : Identifier les obstacles, les risques et les défauts d'une idée.
    - **Questions clés** :
        - Quels sont les dangers ou les points faibles ?
        - Quels problèmes pourraient survenir ?
        - Pourquoi cela pourrait-il échouer ?
4. **Chapeau jaune (Optimisme – Avantages et bénéfices)**
    
    - **Rôle** : Mettre en avant les points positifs, les opportunités et les bénéfices.
    - **Questions clés** :
        - Quels sont les avantages ?
        - Pourquoi cela pourrait fonctionner ?
        - Quels sont les bénéfices potentiels ?
5. **Chapeau vert (Créativité – Nouvelles idées)**
    
    - **Rôle** : Encourager la créativité, l'innovation et les idées alternatives.
    - **Questions clés** :
        - Quelles idées nouvelles pouvons-nous générer ?
        - Comment pouvons-nous dépasser les blocages ?
        - Que pourrions-nous faire différemment ?
6. **Chapeau bleu (Gestion – Organisation de la réflexion)**
    
    - **Rôle** : Structurer la réflexion, définir les objectifs et veiller à ce que le processus reste productif.
    - **Questions clés** :
        - Quel est l'objectif de notre discussion ?
        - Quels chapeaux devons-nous utiliser maintenant ?
        - Quels sont nos résultats ou conclusions ?

---

### **Application pratique**

1. **Définir l'objectif** : Commence par clarifier la problématique ou la décision à explorer.
2. **Organiser les sessions** :
    - Chaque participant (ou le groupe entier) "porte" un chapeau à la fois.
    - On peut alterner les chapeaux selon un ordre prédéfini ou en fonction des besoins.
3. **Encourager la participation équitable** : Chaque voix compte, même si certains chapeaux sont moins "naturels" pour certains.
4. **Prendre des notes** : Documenter les réflexions issues de chaque chapeau pour garder une trace et faciliter la prise de décision finale.

---

### **Avantages**

- Structure la réflexion de manière claire.
- Permet d'explorer des perspectives qu'on pourrait négliger autrement.
- Encourage la collaboration en réduisant les conflits inutiles.
- Stimule la créativité et la prise de décision informée.

---

### **Exemple d'utilisation**

**Problème :** Faut-il lancer un nouveau produit sur le marché ?

- **Chapeau blanc** : Quelle est la taille du marché ? Quels sont les coûts ?
- **Chapeau rouge** : Est-ce que je ressens un enthousiasme ou des craintes ?
- **Chapeau noir** : Quelles sont les limites du produit ? Quels risques juridiques ou financiers ?
- **Chapeau jaune** : Quels bénéfices économiques et sociaux cela pourrait-il générer ?
- **Chapeau vert** : Quels angles ou innovations peuvent rendre ce produit unique ?
- **Chapeau bleu** : Récapitulons les conclusions et planifions les prochaines étapes.

---