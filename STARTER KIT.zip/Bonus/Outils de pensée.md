# Outils de pensée

La **[[Méthode des six chapeaux]]** de Edward de Bono est un excellent exemple d'outil de pensée structuré, mais il existe d'autres méthodes similaires qui visent à structurer les réflexions, favoriser la créativité et organiser les prises de décision. Voici un aperçu de ces outils et méthodes :

---

## **1. Mind Mapping (Cartographie Mentale)**

- **Description** : Technique visuelle pour organiser les idées en arborescence autour d'un sujet central.
- **Utilisation** : Idéal pour le brainstorming, le résumé d'informations ou la planification.
- **Outils associés** : FreeMind, XMind, MindMeister.

---

## **2. La Méthode SCAMPER**

- **Acronyme** :
    - **S**ubstitute (Remplacer)
    - **C**ombine (Combiner)
    - **A**dapt (Adapter)
    - **M**odify (Modifier)
    - **P**ut to another use (Réutiliser)
    - **E**liminate (Éliminer)
    - **R**everse (Inverser)
- **Objectif** : Stimuler la créativité pour améliorer ou inventer de nouveaux produits/services.
- **Usage** : Idéal pour les équipes R&D ou les entrepreneurs.

---

## **3. Design Thinking**

- **Phases principales** :
    1. Empathie : Comprendre les besoins des utilisateurs.
    2. Définir : Clarifier les problèmes.
    3. Idéation : Générer des solutions possibles.
    4. Prototype : Créer des versions testables.
    5. Tester : Recueillir des retours pour affiner.
- **Outils associés** : Miro, FigJam, tableaux Kanban.

---

## **4. SWOT (Forces, Faiblesses, Opportunités, Menaces)**

- **Description** : Analyse stratégique structurée en quatre quadrants.
- **Utilisation** : Évaluer une situation, un projet ou une entreprise.
- **Variante** : TOWS (Mise en correspondance stratégique des menaces et opportunités avec les forces et faiblesses).

---

## **5. Le Diagramme d'Ishikawa (ou Diagramme de Cause à Effet)**

- **Alias** : Diagramme en arêtes de poisson.
- **Objectif** : Identifier les causes possibles d'un problème pour le résoudre efficacement.
- **Utilisation** : Gestion de la qualité, résolution de problèmes.

---

## **6. La Méthode Walt Disney**

- **Principe** : Basée sur trois rôles à endosser successivement :
    - **Le Rêveur** : Générer des idées sans contrainte.
    - **Le Réaliste** : Traduire les idées en actions concrètes.
    - **Le Critique** : Identifier les faiblesses et les défis.
- **Utilisation** : Approche créative pour résoudre des problèmes ou développer des projets.

---

## **7. La Méthode 5 Pourquoi**

- **Description** : Technique pour identifier la cause profonde d'un problème en posant successivement cinq questions "Pourquoi ?".
- **Avantage** : Simple et rapide pour creuser un problème en profondeur.
- **Limite** : Plus adaptée à des situations simples.

---

## **8. Les Outils d'[[Intelligence Collective]]**

- **Techniques courantes** :
    - **Brainstorming** : Idées spontanées d'un groupe.
    - **World Café** : Conversations en petits groupes pour partager et développer des idées.
    - **Méthode Delphi** : Consultation d'experts par cycles pour atteindre un consensus.

---

## **9. La Matrice d’Eisenhower**

- **Objectif** : Prioriser les tâches en fonction de leur urgence et importance.
- **Quadrants** :
    - Urgent & Important : À faire immédiatement.
    - Important & Non urgent : À planifier.
    - Non important & Urgent : À déléguer.
    - Non important & Non urgent : À éliminer.

---

## **10. Le Modèle STAR (Situation, Tâche, Action, Résultat)**

- **Utilisation** : Structurer les récits lors d’entretiens ou de rétrospectives.
- **Objectif** : Clarifier les situations en exposant leur contexte et leur résultat.

---

## **11. Le _Gamestorming_**

- **Description** : Approche ludique pour résoudre des problèmes via des jeux structurés.
- **Exemples de techniques** :
    - "Empathy Map" (carte d’empathie).
    - "Dot Voting" (vote par points).
    - "Crazy 8s" (8 idées en 8 minutes).

---

## **12. Les Techniques de Synectique**

- **Objectif** : Rechercher des analogies (directes, symboliques, personnelles) pour stimuler des idées nouvelles.
- **Utilisation** : Résolution créative de problèmes complexes.

---

## **13. La Méthode des Cartes Empathiques**

- **Axes explorés** :
    - Que voit l'utilisateur ?
    - Que pense-t-il et ressent-il ?
    - Que dit-il et fait-il ?
    - Quels sont ses efforts et frustrations ?
- **Utilisation** : Conception centrée sur l'utilisateur.

---

## **14. La Pensée Latérale (Lateral Thinking)**

- **Inventeur** : Edward de Bono (comme les six chapeaux).
- **Principe** : Briser les schémas traditionnels pour résoudre un problème avec une perspective nouvelle.
- **Techniques associées** : Métaphores, questions provocatrices, connexions inattendues.

---

Ces méthodes peuvent être combinées pour répondre à différents besoins et contextes.