
# Posture collaborative ou participative

### Caractéristiques :

- **Objectif** : Co-produire des savoirs avec les sujets d’étude, en valorisant leur expertise.
- **Méthodologie** : Faire participer les membres du groupe étudié à toutes les étapes de la recherche.
- **Éthique** : Respect de l’autonomie et des intérêts des participants.

### Exemples :

- **Recherche-action** : Kurt Lewin a développé des méthodes où les communautés participent activement à leur propre transformation.
- Ethnographie collaborative avec des groupes marginalisés.

### Limites :

- Nécessite une relation de confiance complexe à construire.
- Risque d’influences mutuelles biaisant les résultats.