# Posture critique

### Caractéristiques :

- **Objectif** : Identifier et dénoncer les rapports de domination, d’inégalités ou d’oppression dans la société.
- **Méthodologie** : S’engager dans une analyse critique pour proposer des alternatives ou des solutions.
- **Éthique** : Prend position sur les enjeux sociaux et assume une subjectivité.

### Exemples :

- L'École de Francfort (Adorno, Horkheimer) : critique de l'aliénation produite par la culture de masse.
- Pierre Bourdieu : dénonciation des inégalités sociales et du pouvoir symbolique.

### Limites :

- Peut être accusée de manquer d’objectivité.
- Risque de transformer la recherche en militantisme.