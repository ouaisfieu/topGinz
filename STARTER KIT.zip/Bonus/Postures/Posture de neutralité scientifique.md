
# Posture de neutralité scientifique
### Caractéristiques :

- **Objectif** : Observer et analyser les phénomènes sociaux sans y participer ni les influencer.
- **Méthodologie** : Observer, décrire et expliquer en gardant une distance avec le sujet d'étude.
- **Éthique** : Préserver une objectivité stricte pour éviter les biais.

### Exemples :

- L’approche positiviste d'Émile Durkheim, qui étudiait les faits sociaux comme des "choses" indépendantes de l'observateur.

### Limites :

- Peut être perçue comme froide ou déshumanisante.
- Difficile à appliquer totalement, car le chercheur a toujours des biais culturels ou personnels.