
# Posture engagée ou militante

### Caractéristiques :

- **Objectif** : Utiliser la recherche pour soutenir des causes sociales ou politiques.
- **Méthodologie** : Collaborer étroitement avec les groupes étudiés, parfois pour renforcer leur pouvoir d'action.
- **Éthique** : Assume explicitement son parti-pris.

### Exemples :

- **Féminisme** : Sociologues comme Dorothy Smith analysent les structures sociales à travers le prisme du genre.
- **Études décoloniales** : Examen critique des rapports Nord-Sud, des colonialismes, et de leurs héritages.

### Limites :

- Accusations potentielles de manque de rigueur scientifique.
- Difficile de convaincre des publics en désaccord idéologique.