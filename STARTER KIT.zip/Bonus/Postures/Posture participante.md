# Posture participante

### Caractéristiques :

- **Objectif** : S’intégrer dans le groupe étudié pour mieux comprendre les phénomènes de l’intérieur.
- **Méthodologie** : L’ethnographe ou sociologue devient un acteur dans le milieu étudié, tout en restant analytique.
- **Éthique** : Exige de la transparence vis-à-vis des participants sur le rôle du chercheur.

### Exemples :

- **Malinowski** (anthropologue) : a vécu parmi les Trobriandais pour comprendre leur société.
- **Howard Becker** : a participé à des groupes sociaux (musiciens, fumeurs de marijuana) pour comprendre leurs pratiques.

### Limites :

- Risque de perdre la distance critique.
- Influence potentielle sur le comportement des sujets (effet d’observation).