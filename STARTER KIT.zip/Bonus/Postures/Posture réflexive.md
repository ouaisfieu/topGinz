# Posture réflexive

### Caractéristiques :

- **Objectif** : Reconnaître l’impact du chercheur sur le sujet d’étude et intégrer cette influence dans l’analyse.
- **Méthodologie** : Interroger ses propres biais, son positionnement et son rôle dans le processus de recherche.
- **Éthique** : Transparence sur les choix méthodologiques et la subjectivité du chercheur.

### Exemples :

- **Pierre Bourdieu** : appel à une sociologie réflexive, qui prend en compte la position sociale du chercheur.
- **Clifford Geertz** : "thick description" (description dense) qui montre les interprétations multiples du chercheur.

### Limites :

- Peut ralentir le processus de recherche.
- Risque de trop centrer l’analyse sur le chercheur.