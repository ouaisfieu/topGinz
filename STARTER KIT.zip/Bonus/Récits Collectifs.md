# Récits Collectifs

### **Les récits collectifs : définition et origines**

Les **récits collectifs** sont des histoires construites à plusieurs voix, à partir d’expériences individuelles et partagées par un groupe. Ils permettent de relier les vécus personnels à une trame commune, donnant ainsi du sens aux expériences individuelles tout en mettant en lumière des enjeux collectifs.

Ce concept s’inscrit dans des démarches qui croisent **l’éducation populaire, l’anthropologie, la sociologie et la narration politique**. Il est utilisé dans des contextes variés, allant de la **lutte sociale** à la **recherche-action**, en passant par les **méthodes participatives** et la **création artistique engagée**.

---

### **D’où vient ce concept ?**

#### **1. Origines anthropologiques et sociologiques**

Le récit collectif est une pratique ancienne : dans de nombreuses sociétés, **les mythes, les légendes et les traditions orales** servent à transmettre des savoirs, des valeurs et des identités culturelles. Des chercheurs comme **Paul Ricoeur** (philosophie de la narration) et **Walter Benjamin** (rôle du conteur) ont montré comment la narration permet de structurer l’expérience humaine et de la transmettre aux générations suivantes.

Dans les sciences sociales, **Pierre Bourdieu** et **Howard Becker** ont travaillé sur les récits de vie pour comprendre les structures sociales et les processus d’exclusion ou de résistance.

#### **2. Éducation populaire et mouvements sociaux**

Les récits collectifs sont aussi au cœur des luttes sociales et de l’**éducation populaire**. Des pédagogues comme **Paulo Freire** (avec la pédagogie de l’opprimé) ont utilisé le récit comme un moyen d’**émancipation**, en aidant les populations marginalisées à prendre conscience de leur réalité et à la transformer.

Les **mouvements féministes** ont largement mobilisé cette approche : dans les années 1970, des groupes de femmes ont collecté et partagé leurs témoignages pour mettre en lumière des oppressions systémiques et créer du changement (ex. : le travail de **bell hooks** sur la narration et l’identité).

#### **3. Innovation dans la participation citoyenne et la démocratie**

Aujourd’hui, les récits collectifs sont utilisés pour **mobiliser les citoyens**, que ce soit dans des projets de **démocratie participative**, des **documentaires citoyens**, des **théâtres-forums**, ou des plateformes de partage d’expériences (comme les archives vivantes du mouvement Black Lives Matter, les chroniques du climat, etc.).

---

### **Pourquoi les récits collectifs sont importants en éducation permanente ?**

1. **Ils donnent une voix aux personnes invisibilisées.**
2. **Ils créent du lien social et renforcent l’identité collective.**
3. **Ils permettent d’analyser ensemble les inégalités et les oppressions.**
4. **Ils aident à imaginer des alternatives et à construire du changement.**

En somme, les récits collectifs sont à la fois un **outil d’analyse**, un **levier d’action** et un **moyen d’émancipation**. Ils sont donc au cœur des démarches de transformation sociale portées par l’éducation permanente.

---

