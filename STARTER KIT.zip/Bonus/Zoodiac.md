
# Zodiaque Animalier


1. **Le Pigeon (21 mars – 19 avril)**
    
    - _Traits de personnalité_ : Toujours prêt à partager ses opinions, même non sollicitées. Bienveillant mais un peu naïf, il est souvent la proie des escroqueries urbaines.
    - _Mantra_ : « Partager, c’est vivre, même si c’est du pain rassis. »
2. **Le Dindon (20 avril – 20 mai)**
    
    - _Traits de personnalité_ : Généreux de nature, mais souvent pris pour le dindon de la farce. Aime impressionner avec ses talents cachés, bien qu’ils soient parfois incompris.
    - _Mantra_ : « On peut être fier, même avec des plumes. »
3. **Le Blaireau (21 mai – 20 juin)**
    
    - _Traits de personnalité_ : Persévérant et un brin têtu. Il ne cède jamais, même quand il est en tort. Sa devise : « Si je suis là, c’est pour rester. »
    - _Mantra_ : « Un terrier bien creusé est un terrier à jamais. »
4. **Le Raton Laveur (21 juin – 22 juillet)**
    
    - _Traits de personnalité_ : Curieux, plein de ressources, et adorant fouiller là où il ne faut pas. Attachant malgré ses escapades nocturnes.
    - _Mantra_ : « Tout ce qui brille mérite d’être volé. »
5. **Le Paresseux (23 juillet – 22 août)**
    
    - _Traits de personnalité_ : Calme et contemplatif. Prend la vie avec un détachement total. Les deadlines ? C’est pour les autres.
    - _Mantra_ : « Pourquoi courir quand on peut dormir ? »
6. **Le Perroquet (23 août – 22 septembre)**
    
    - _Traits de personnalité_ : Imite bien et parle beaucoup. Il a toujours le dernier mot (parfois emprunté). Aime donner son avis sur tout, même sans expertise.
    - _Mantra_ : « Répéter, c’est exister. »
7. **Le Hérisson (23 septembre – 22 octobre)**
    
    - _Traits de personnalité_ : Sociable mais avec prudence. Se protège dès que les choses deviennent trop sérieuses. Adorable de loin, piquant de près.
    - _Mantra_ : « Un câlin ? Peut-être… »
8. **La Mouette (23 octobre – 21 novembre)**
    
    - _Traits de personnalité_ : Opportuniste et bruyante. Amoureuse des moments dramatiques, elle attire l’attention sans même le vouloir.
    - _Mantra_ : « Tout ce qui tombe est à moi. »
9. **Le Castor (22 novembre – 21 décembre)**
    
    - _Traits de personnalité_ : Travailleur acharné, il construit ses rêves un bâton à la fois. Aime l’ordre, mais peut inonder son entourage avec ses idées.
    - _Mantra_ : « Chaque tronc mérite un barrage. »
10. **La Chauve-Souris (22 décembre – 19 janvier)**
    
    - _Traits de personnalité_ : Mystérieuse et décalée, elle vit la nuit et ne suit pas les règles conventionnelles. Pragmatique et perspicace.
    - _Mantra_ : « Voir sans être vu, c’est l’art de vivre. »
11. **Le Lama (20 janvier – 18 février)**
    
    - _Traits de personnalité_ : Un peu excentrique et imprévisible, il crache quand il est agacé. Mais il est aussi amical et très loyal.
    - _Mantra_ : « Garder la tête haute, même après un crachat. »
12. **Le Pangolin (19 février – 20 mars)**
    
    - _Traits de personnalité_ : Réservé et sensible, il se protège des agressions du monde extérieur. Rare et un peu méconnu, mais plein de profondeur.
    - _Mantra_ : « Se replier pour mieux se retrouver. »

---

- **Le Pingouin (29 février, signe alternatif)**
    
    - _Traits de personnalité_ : Élégant et toujours bien habillé, même en situation de crise. Optimiste face à l'adversité, il glisse sur les difficultés avec style. Rêve de voler, mais reste réaliste quant à ses limites.
    - _Mantra_ : « Il n’y a pas de pente trop glissante pour un pingouin. »
- **La Mouffette (29 février, signe alternatif)**
    
    - _Traits de personnalité_ : Indépendante et pleine d’assurance, elle ne craint pas de marquer son territoire. Sociable mais méfiante, elle sait se défendre quand on dépasse les limites. Paradoxalement attachante, même si on garde ses distances.
    - _Mantra_ : « Mieux vaut prévenir que subir. »

---

### Édition Underground et Bizarre

15. **Le Corbeau**
    
    - _Traits de personnalité_ : Esprit sombre et mystérieux, il aime observer sans se dévoiler. Un peu philosophe, souvent sarcastique. Maître des secrets et des récits sinistres.
    - _Mantra_ : « L’ombre parle à qui sait écouter. »
16. **Le Gecko**
    
    - _Traits de personnalité_ : Décontracté, avec un air de cool permanent. Sait se fondre dans son environnement pour se démarquer d’une manière subtile. Fan de musique underground et de soirées intimes.
    - _Mantra_ : « L’art de la discrétion est un acte de rébellion. »
17. **Le Paon (version underground)**
    
    - _Traits de personnalité_ : Frimeur et excentrique, mais avec un penchant pour l’art alternatif et les happenings inattendus. Adore les projecteurs, mais uniquement dans les clubs branchés et cachés.
    - _Mantra_ : « Briller, mais pour ceux qui savent voir. »
18. **Le Suricate**
    
    - _Traits de personnalité_ : Toujours en alerte, il a l’air innocent mais est au courant de toutes les affaires louches du quartier. Sociable et un brin hyperactif.
    - _Mantra_ : « Mieux vaut prévenir avant que ça dégénère. »
19. **La Pieuvre**
    
    - _Traits de personnalité_ : Polyvalente et insaisissable, elle a mille talents cachés. Maîtresse du multitâche et des plans secrets. Aime les ambiances un peu psychédéliques.
    - _Mantra_ : « Il y a toujours une tentacule en réserve. »
20. **Le Chinchilla**
    
    - _Traits de personnalité_ : Peluche de l’underground, il frime sans s’en rendre compte. Toujours à la recherche de la fête la plus secrète et du canapé le plus moelleux.
    - _Mantra_ : « Luxueux, mais à ma façon. »
21. **Le Coq de Combat**
    
    - _Traits de personnalité_ : Arrogant et audacieux, il n’a peur de rien ni de personne. Son look est toujours affûté, et il se pavane dans les rues comme sur un ring.
    - _Mantra_ : « Qui ose gagne, qui crâne règne. »
22. **Le Phalène**
    
    - _Traits de personnalité_ : Fasciné par la lumière étrange, il est attiré par tout ce qui est hors norme. Charismatique dans son étrangeté et amical avec ceux qui partagent sa bizarrerie.
    - _Mantra_ : « Se perdre dans la lueur, c’est trouver son chemin. »
23. **Le Rat de Ville**
    
    - _Traits de personnalité_ : Malin et adaptable, il connaît tous les recoins cachés de la ville. Opportuniste et audacieux, il peut passer du chic à l'underground sans effort.
    - _Mantra_ : « Survivre, c’est aussi savoir briller dans les égouts. »
24. **Le Chat de Sphinx**
    
    - _Traits de personnalité_ : Enigmatique et légèrement effrayant. Aime le mysticisme et les rituels étranges. Frimeur sans poils, il attire l'attention des initiés.
    - _Mantra_ : « Mystère et vérité se cachent sous la peau. »