# Adapter

> Modifier pour s'ajuster à une nouvelle situation ou contexte.

[[vrac]]