# Admettre

> Reconnaître ou accepter une vérité ou une réalité.

[[VORTEXT/K]]