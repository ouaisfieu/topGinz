# Agir

> Mettre en œuvre une décision par une action.

[[vrac]]