# Améliorer

> Augmenter la qualité ou la performance de quelque chose.

[[vrac]]