# Analyser

> Décomposer un sujet en éléments fondamentaux pour en comprendre la structure.

[[F]]