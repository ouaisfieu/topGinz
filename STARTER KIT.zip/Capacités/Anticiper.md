# Anticiper

> Prévoir et se préparer à des événements futurs.

[[H]]