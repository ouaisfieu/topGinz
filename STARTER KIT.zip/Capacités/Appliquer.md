# Appliquer

> Mettre en pratique une méthode ou un concept.

[[vrac]]