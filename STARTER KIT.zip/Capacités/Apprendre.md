# Apprendre

> Acquérir de nouvelles connaissances ou compétences.

[[D]]