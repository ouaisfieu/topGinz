# Argumenter

> Présenter des raisons pour justifier une opinion ou une position.

[[G]]