# Assurer

> Garantir la sécurité ou la fiabilité de quelque chose.

[[vrac]]