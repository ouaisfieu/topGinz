# Avoir

> Posséder ou disposer de quelque chose.

[[vrac]]