# Axiomiser

> Énoncer des principes fondamentaux indémontrables mais acceptés comme base de raisonnement.

[[B]]