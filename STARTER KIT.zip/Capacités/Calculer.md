# Calculer

> Effectuer des opérations mathématiques pour obtenir un résultat.

[[VORTEXT/K]]