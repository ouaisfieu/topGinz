# Choisir

> Sélectionner parmi plusieurs options.

[[H]]