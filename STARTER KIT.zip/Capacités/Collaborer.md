# Collaborer

> Travailler conjointement avec d'autres pour atteindre un objectif commun.

[[vrac]]