# Combiner

> Fusionner plusieurs éléments en un tout cohérent.

[[C]]