# Communiquer

> Échanger des informations ou des idées.

[[vrac]]