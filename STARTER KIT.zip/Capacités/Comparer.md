# Comparer

> Évaluer les similitudes et les différences entre plusieurs éléments.

[[C]]