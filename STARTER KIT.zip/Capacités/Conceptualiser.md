# Conceptualiser

> Formuler des idées ou des concepts abstraits.

[[B]]