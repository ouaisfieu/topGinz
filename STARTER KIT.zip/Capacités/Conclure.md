# Conclure

> Arriver à une décision finale après réflexion.

[[E]]