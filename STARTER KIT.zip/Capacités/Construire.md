# Construire

> Assembler des composants pour créer une structure ou un système.

[[vrac]]