# Critiquer

> Évaluer quelque chose en soulignant ses points forts et faibles.

[[F]]