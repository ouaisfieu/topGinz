# Discuter

> Échanger des points de vue sur un sujet donné.

[[G]]