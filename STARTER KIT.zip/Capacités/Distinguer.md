# Distinguer

> Reconnaître des différences distinctes entre plusieurs éléments.

[[C]]