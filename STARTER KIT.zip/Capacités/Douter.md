# Douter

> Remettre en question la certitude de quelque chose.

[[D]]