# Décider

> Faire un choix après délibération.

[[H]]