# Déduire

> Tirer une conclusion logique à partir de prémisses.

[[F]]