# Démontrer

> Prouver quelque chose par des preuves ou des arguments.

[[E]]