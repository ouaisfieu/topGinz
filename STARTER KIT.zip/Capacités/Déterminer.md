# Déterminer

> Fixer ou établir précisément.

[[VORTEXT/K]]