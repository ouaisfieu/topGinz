# Enregistrer

> Capturer et conserver des informations.

[[I]]