# Envisager

> Considérer une possibilité future.

[[VORTEXT/K]]