# Estimer

> Évaluer approximativement la valeur ou l'importance de quelque chose.

[[G]]