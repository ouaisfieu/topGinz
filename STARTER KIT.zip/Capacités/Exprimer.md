# Exprimer

> Communiquer une idée, une pensée ou un sentiment.

[[G]]