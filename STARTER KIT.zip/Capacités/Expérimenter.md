# Expérimenter

> Tester pour observer des résultats ou effets.

[[vrac]]