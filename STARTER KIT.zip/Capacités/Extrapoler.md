# Extrapoler

> Déduire des informations futures basées sur des données actuelles.

[[F]]