# Faciliter

> Rendre une tâche plus simple à accomplir.

[[vrac]]