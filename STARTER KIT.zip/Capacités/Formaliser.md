# Formaliser

> Structurer ou organiser quelque chose de manière systématique.

[[B]]