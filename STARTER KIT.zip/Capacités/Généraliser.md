# Généraliser

> Appliquer une conclusion à des cas plus larges.

[[B]]