# Induire

> Tirer une conclusion générale à partir de cas particuliers.

[[F]]