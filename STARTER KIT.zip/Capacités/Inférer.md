# Inférer

> Déduire une conclusion à partir de preuves ou d’indices.

[[F]]