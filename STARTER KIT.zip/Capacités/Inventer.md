# Inventer

> Créer quelque chose qui n'existait pas auparavant.

[[A]]