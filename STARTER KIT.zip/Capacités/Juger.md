# Juger

> Porter un jugement ou une opinion sur quelque chose.

[[H]]