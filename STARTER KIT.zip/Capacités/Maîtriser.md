# Maîtriser

> Acquérir une compétence ou une connaissance approfondie.

[[D]]