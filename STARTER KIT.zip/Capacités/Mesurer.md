# Mesurer

> Évaluer la dimension, la quantité ou la capacité.

[[VORTEXT/K]]