# Modéliser

> Représenter quelque chose sous forme de modèle ou de système.

[[B]]