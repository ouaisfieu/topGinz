# Motiver

> Inciter quelqu'un à agir.

[[vrac]]