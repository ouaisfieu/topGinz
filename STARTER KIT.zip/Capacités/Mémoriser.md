# Mémoriser

> Retenir des informations pour une récupération ultérieure.

[[I]]