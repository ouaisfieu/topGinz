# Naviguer

> Se diriger ou se déplacer dans un espace.

[[vrac]]