# Négocier

> Trouver un accord par discussion.

[[vrac]]