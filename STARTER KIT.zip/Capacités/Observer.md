# Observer

> Regarder attentivement pour acquérir des informations.

[[vrac]]