# Opposer

> Placer en contraste ou en conflit.

[[C]]