# Optimiser

> Rendre quelque chose aussi efficace que possible.

[[vrac]]