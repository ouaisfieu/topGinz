# Penser

> Utiliser l'esprit pour former des idées et résoudre des problèmes.

[[D]]