# Planifier

> Définir des étapes pour atteindre un objectif.

[[vrac]]