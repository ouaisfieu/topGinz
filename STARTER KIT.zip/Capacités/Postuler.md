# Postuler

> Proposer une idée comme hypothèse.

[[VORTEXT/K]]