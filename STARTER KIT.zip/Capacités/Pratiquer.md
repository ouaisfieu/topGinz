# Pratiquer

> Exercer une activité régulièrement pour s'améliorer.

[[D]]