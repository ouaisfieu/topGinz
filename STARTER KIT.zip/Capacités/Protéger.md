# Protéger

> Défendre contre des dangers ou des dommages.

[[vrac]]