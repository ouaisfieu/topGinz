# Prouver

> Fournir des preuves de la véracité de quelque chose.

[[E]]