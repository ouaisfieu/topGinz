# Préserver

> Maintenir en bon état.

[[vrac]]