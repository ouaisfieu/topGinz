# Raisonner

> Utiliser la logique pour arriver à une conclusion.

[[F]]