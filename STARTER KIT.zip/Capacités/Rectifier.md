# Rectifier

> Corriger une erreur ou un défaut.

[[G]]