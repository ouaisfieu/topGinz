# Ressentir

> Percevoir des émotions ou des sensations.

[[vrac]]