# Rêver

> Imaginer des situations ou des scénarios idéalisés.

[[A]]