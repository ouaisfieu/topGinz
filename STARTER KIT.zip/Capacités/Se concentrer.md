# Se concentrer

> Porter toute son attention sur un sujet.

[[I]]