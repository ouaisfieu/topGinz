# Se souvenir

> Rappeler à la mémoire des informations passées.

[[I]]