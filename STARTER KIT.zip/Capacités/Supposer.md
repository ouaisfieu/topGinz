# Supposer

> Prendre quelque chose pour vrai sans preuve certaine.

[[VORTEXT/K]]