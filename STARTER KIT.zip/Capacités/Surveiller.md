# Surveiller

> Observer attentivement pour détecter des changements.

[[vrac]]