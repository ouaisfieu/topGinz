# Synthétiser

> Combiner des éléments pour former un tout cohérent.

[[vrac]]