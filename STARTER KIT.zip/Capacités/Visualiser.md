# Visualiser

> Former une image mentale de quelque chose.

[[A]]