# Vérifier

> Confirmer l'exactitude ou la validité de quelque chose.

[[VORTEXT/K]]