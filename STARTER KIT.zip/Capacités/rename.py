import os

# Récupérer le dossier où se trouve le script
dossier = os.getcwd()

# Parcourir les fichiers dans le dossier
for fichier in os.listdir(dossier):
    if fichier.endswith(".doc"):  # Vérifie si l'extension est .doc
        ancien_chemin = os.path.join(dossier, fichier)
        nouveau_chemin = os.path.join(dossier, fichier[:-4])  # Supprime ".doc"
        os.rename(ancien_chemin, nouveau_chemin)
        print(f"Renommé : {fichier} → {fichier[:-4]}")

print("Tous les fichiers .doc ont été renommés.")
