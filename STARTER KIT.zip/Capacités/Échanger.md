# Échanger

> Donner quelque chose et recevoir autre chose en retour.

[[vrac]]