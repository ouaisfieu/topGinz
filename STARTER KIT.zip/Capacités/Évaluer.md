# Évaluer

> Juger de la valeur ou de la qualité de quelque chose.

[[VORTEXT/K]]