# Être

> Exister ou se manifester.

[[vrac]]