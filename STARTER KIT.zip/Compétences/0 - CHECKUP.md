
---


# CHECKUP



Explorer le monde, 
Le découvrir à travers les sens.

Comprendre que ce qui n'est pas visible existe peut-être.
Comprendre que ce qui existe est en mouvement.
Pouvoir utiliser ce qui existe.

---

- [ ] Explorer le monde
- [ ] Découvrir le monde à travers les sens
- [ ] Entrevoir l'invisible
- [ ] Entrevoir le mouvement
- [ ] Agir sur le monde

---


[[1 - PRÉOPÉRATION]]


---


