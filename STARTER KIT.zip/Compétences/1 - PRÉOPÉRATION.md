


---



# PRÉOPÉRATION




Pouvoir utiliser des symboles pour représenter des objets et des idées



---



- [ ] Se centrer sur soi
- [ ] Reconnaitre une valeur au vivant
- [ ] Reconnaître ses limites



---




[[2 - CONCRÉTISATION]]


---


