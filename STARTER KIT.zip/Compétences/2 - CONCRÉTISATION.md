


---



# CONCRÉTISATION

Développement de la pensée logique appliquée à des objets concrets et à des situations pratiques.



---

- [ ] Reconnaître des caractéristiques communes
- [ ] Organiser des objets en catégories
- [ ] Observer des transformations d'un état à l'autre



---


[[3 - OPÉRATIONS]]


---
