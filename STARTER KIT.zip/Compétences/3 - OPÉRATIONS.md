


---
# OPÉRATIONS

Capacité de penser de manière abstraite et de raisonner au-delà des situations concrètes et immédiates.


---


- [ ] Élaborer des hypothèses
- [ ] Élaborer des stratégies
- [ ] Réfléchir aux implications des théories et des propos
- [ ] Anticiper les conséquences de ses choix
- [ ] Penser à des concepts abstraits
- [ ] Planifier à long terme
- [ ] Raisonner sur des situations hypothétiques
- [ ] Comprendre des métaphores
- [ ] Comprendre des allégories
- [ ] Aborder des [[Concepts théoriques complexes|concepts théoriques complexes]]
- [ ] Remettre en question des idées
- [ ] Débattre des points de vue
- [ ] Pouvoir conceptualiser des idées qui n'existent pas encore
- [ ] Comprendre comment les parties d'un système interagissent



---


[[4 - OPTIMISATION]]



---



