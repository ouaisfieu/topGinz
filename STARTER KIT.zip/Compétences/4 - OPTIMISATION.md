


---


# OPTIMISATION


- [ ] Apprendre en continu
- [ ] Apprendre à apprendre
- [ ] Faire des liens entre les concepts
- [ ] Approfondir les connaissances
- [ ] Remettre en question ses connaissances
- [ ] Envisager plusieurs solutions possibles à un problème
- [ ] Repérer les méthodes les plus efficaces
- [ ] Résoudre des problèmes, et optimiser leurs solutions
- [ ] Voir des relations et des schémas que d'autres ne voient pas
- [ ] Associer des concepts des manière innovante
- [ ] Penser de manière créative
- [ ] Expérimenter et explorer des idées non conventionnelles
- [ ] Réfléchir sur sa propre pensée et ses mécanismes de pensée
- [ ] Pouvoir changer de stratégie face à un obstacle
- [ ] Explorer et tenter de comprendre le monde

---




[[Guide Ultime du Génie - Deklet et.al.]]


---
