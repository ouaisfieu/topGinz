Ton identité n'existe pas dans un vide ; elle est influencée par les normes, les traditions et les attentes de la société dans laquelle tu vis. Ce que tu considères comme "normal" ou "approprié" dépend en grande partie de ton environnement culturel et social.

- **Normes sociales :** Les attentes de la société concernant ce qu’est un comportement "acceptable" jouent un rôle dans ta façon de te comporter et de te percevoir. Par exemple, certains traits de personnalité comme l’indépendance peuvent être valorisés dans une culture et marginalisés dans une autre.
    
- **Croyances partagées :** Les idéologies, les religions et les traditions culturelles partagées influencent tes valeurs et la manière dont tu juges le monde. Les croyances collectives façonnent également la façon dont tu conçois des concepts abstraits comme la justice, la liberté ou l'amour.
    

**Impact sur l’identité :**  
Ta culture et ta société t’orientent vers une certaine façon de voir le monde. Cela peut être positif, en renforçant un sentiment d'appartenance, ou plus contraignant, en limitant certaines formes d’expression ou de pensée.

voir aussi : [[question - qui-suis-je]]