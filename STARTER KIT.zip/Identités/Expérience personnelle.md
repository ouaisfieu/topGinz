# Expérience personnelle

Ce que tu vis au [[quotidien]] façonne directement ta perception du monde et influence la personne que tu deviens. Ton éducation, ton [[milieu socio-culturel]], et les [[événements marquants]] de ta vie te façonnent profondément :

- **L’[[éducation]] et l’[[apprentissage]] :** La manière dont tu as été éduqué, les [[AIDES/DICO - GPTPardi/Valeurs|valeurs]] qui t’ont été inculquées, et les connaissances que tu as acquises influencent tes [[croyances]], ton raisonnement et ta vision du monde.
    
- **Les [[interactions sociales]] :** Chaque relation, qu’elle soit familiale, amicale ou professionnelle, te modèle. Le contexte social dans lequel tu évolues affecte tes [[normes]], tes [[habitudes]] et ton [[éthique]].
    
- **Les événements marquants :** Les moments forts (positifs ou négatifs) de ta vie, comme les [[succès]], les [[échecs]], les deuils ou les [[découvertes]], laissent une empreinte durable sur ta conscience et sur ta façon de [[jugement|juger]] et d’évaluer le monde.
    

**Impact sur la conscience :**  
Ton vécu contribue à définir ton [[Système de valeurs]], ta [[perception de l’autre]], et ton [[Jugement moral]]. Par exemple, des expériences d’échec peuvent te rendre plus prudent dans tes décisions, tandis que des réussites te rendront peut-être plus confiant.


revoir :
 - [[ma bio man]]
 - [[je - 1 - voir - mon identité]]
 - [[je - 2 - suis-je - checkASAP]]

