
# IDENTITÉS DE GENRES

Voici une liste d'identités de genre avec une brève description de chacune :

### 1. **[[Masculin]] (Homme)**

- Personne qui s'identifie comme un homme, associée traditionnellement aux rôles masculins dans la société.

### 2. **[[Féminin]] (Femme)**

- Personne qui s'identifie comme une femme, souvent liée aux rôles féminins traditionnels dans la société.

### 3. **[[Non-binaire]]**

- Identité qui ne correspond pas strictement aux catégories masculines ou féminines. Les personnes non-binaires peuvent se sentir quelque part entre les genres, un mélange des deux, ou complètement en dehors du spectre binaire.

### 4. **[[Genre fluide]]**

- Une identité de genre qui varie ou change au fil du temps. Une personne de genre fluide peut se sentir masculine, féminine, non-binaire, ou d'autres genres à différents moments.

### 5. **[[Genrequeer]]**

- Terme générique pour désigner les personnes qui ne se conforment pas aux normes binaires de genre. Peut inclure le non-binaire, le genre fluide, et d'autres identités.

### 6. **[[Agender]]**

- Personne qui ne s'identifie à aucun genre. Une personne agender peut se sentir neutre ou sans genre.

### 7. **[[Bigender]]**

- Personne qui s'identifie à deux genres, que ce soit simultanément ou à différents moments. Par exemple, une personne peut se sentir masculine et féminine, ou masculine et non-binaire.

### 8. **[[Demi-genre]] (Demi-boy/Demi-girl)**

- Personne qui s'identifie partiellement comme un certain genre (par exemple, partiellement homme ou femme), mais pas complètement.

### 9. **[[Genderfluid]]**

- Synonyme de genre fluide, mais souvent utilisé pour décrire des personnes dont l'identité de genre varie fréquemment ou change rapidement.

### 10. **[[Androgyne]]**

- Personne dont l'identité de genre est un mélange de traits masculins et féminins, ou qui se sent à la fois homme et femme.

### 11. **Gender non-conforming ([[Non conforme au genre]])**

- Terme générique pour désigner une personne dont l'expression ou l'identité de genre diffère des normes traditionnelles ou des attentes de la société.

### 12. **Two-Spirit ([[Bispirituel]])**

- Identité propre aux cultures autochtones d'Amérique du Nord, désignant une personne qui incarne à la fois les traits masculins et féminins. C’est un rôle spirituel et social unique à chaque tribu.

### 13. **[[Neutrois]]**

- Identité de genre neutre, souvent associée à un sentiment d'absence ou de neutralité de genre.

### 14. **Autre genre ([[Xénogenre]])**

- Identité de genre qui ne peut être décrite dans le cadre des concepts traditionnels de genre. Par exemple, certaines personnes peuvent se sentir liées à des concepts abstraits ou non humains.

### 15. **[[Polygender]]**

- Personne qui s'identifie à plusieurs genres en même temps ou qui change entre plusieurs genres.

### 16. **Third Gender ([[Troisième genre]])**

- Concept qui varie selon les cultures, désignant des personnes qui ne sont ni homme ni femme mais qui appartiennent à un troisième genre reconnu par certaines sociétés.

### 17. **[[Hijra]]**

- Communauté traditionnelle en Asie du Sud (notamment en Inde, au Pakistan et au Bangladesh) qui inclut des personnes assignées homme à la naissance mais qui s'identifient comme femme ou comme une identité de genre distincte.

### 18. **[[Transgenre]]**

- Terme générique pour les personnes dont l'identité de genre diffère du sexe assigné à la naissance. Une personne transgenre peut s'identifier comme homme, femme, non-binaire, etc.

### 19. **[[Cisgenre]]**

- Personne dont l'identité de genre correspond au sexe assigné à la naissance.

### 20. **[[Intergenre]]**

- Identité de genre qui peut être vécue par des personnes intersexes ou d'autres personnes qui ne s'identifient ni complètement comme homme ni comme femme.

Ces identités montrent la diversité de l'expérience humaine en matière de genre. La compréhension et la reconnaissance de ces identités sont essentielles pour créer un environnement inclusif et respectueux.