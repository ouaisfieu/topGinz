# PROFILS TYPES

Si on part du principe que tout est à refaire et que l'on souhaite inclure tous les types de personnes dans ce nouveau monde, il est utile d'envisager la diversité humaine à travers plusieurs dimensions. Voici quelques catégories qui peuvent aider à structurer cette diversité :

### 0. Profils types de base

1. **Les valeurs et croyances :**
    
    - **[[Altruistes]]** : Ceux qui mettent l’accent sur le bien commun et l'entraide.
    - **[[Individuels]]** : Ceux qui préfèrent agir selon leur propre bénéfice et indépendance.
    - **[[Spiritualistes]]** : Ceux qui orientent leur vie selon des convictions religieuses ou spirituelles.
    - **[[Pragmatiques]]** : Ceux qui privilégient les faits concrets et la réalité observable.
2. **Les comportements sociaux :**
    
    - **[[Leaders]]** : Ceux qui prennent l'initiative et guident les autres.
    - **[[Suiveurs]]** : Ceux qui préfèrent soutenir et suivre les directives des leaders.
    - **[[Solitaires]]** : Ceux qui recherchent avant tout la tranquillité et la solitude.
    - **[[Collaborateurs]]** : Ceux qui apprécient travailler en équipe et construire ensemble.
3. **Les attitudes face aux défis :**
    
    - **[[Optimistes]]** : Ceux qui voient toujours les opportunités, même dans l'adversité.
    - **[[Pessimistes]]** : Ceux qui anticipent les difficultés avant tout.
    - **[[Résilients]]** : Ceux qui rebondissent face aux épreuves.
    - **[[Aventuriers]]** : Ceux qui cherchent constamment à explorer et repousser les limites.
4. **Les profils cognitifs :**
    
    - **[[Créatifs]]** : Ceux qui imaginent de nouvelles solutions et idées.
    - **[[Analytiques]]** : Ceux qui se concentrent sur la logique et la rigueur.
    - **[[Empathiques]]** : Ceux qui sont particulièrement sensibles aux émotions et besoins des autres.
    - **[[Systématiques]]** : Ceux qui aiment structurer et organiser les informations.
5. **Les compétences pratiques et métiers :**
    
    - **[[Artisans et créateurs]]** : Ceux qui fabriquent et conçoivent des objets, des œuvres ou des outils.
    - **[[Scientifiques et ingénieurs]]** : Ceux qui cherchent à comprendre les lois du monde et à innover technologiquement.
    - **[[Éducateurs]]** : Ceux qui partagent le savoir et forment les autres.
    - **[[Agriculteurs]] et protecteurs de la nature** : Ceux qui veillent à l’équilibre de la terre et des ressources naturelles.
6. **Les approches de la justice et de la morale :**
    
    - **[[Justiciers]]** : Ceux qui luttent pour l'équité et la justice.
    - **[[Médiateurs]]** : Ceux qui cherchent à réconcilier les conflits et maintenir la paix.
    - **[[Libéraux]]** : Ceux qui prônent la liberté individuelle avant tout.
    - **[[Conservateurs]]** : Ceux qui privilégient les traditions et la stabilité.
7. **Les personnalités en termes de caractère :**
    
    - **[[Extravertis]]** : Ceux qui se nourrissent du contact social.
    - **[[Introvertis]]** : Ceux qui préfèrent la réflexion personnelle et des interactions plus calmes.
    - **[[Sanguins]]** : Enthousiastes et énergiques, ils s'expriment souvent et facilement.
    - **[[Flegmatiques]]** : Calmes et réfléchis, ils sont moins enclins à réagir spontanément.
8. **Les aspirations et passions :**
    
    - **[[Explorateurs]]** : Ceux qui cherchent à découvrir de nouveaux horizons, qu'ils soient physiques ou intellectuels.
    - **[[Conservateurs]]** : Ceux qui veillent à maintenir l'ordre et la continuité.
    - **[[Innovateurs]]** : Ceux qui cherchent constamment à changer et à améliorer.
    - **[[Traditionnalistes]]** : Ceux qui préfèrent le retour aux valeurs anciennes et à la continuité des pratiques.
9. **Les sensibilités culturelles et esthétiques :**
    
    - **[[Amateurs d'art et de culture]]** : Ceux qui valorisent l'expression artistique, la musique, et les traditions culturelles.
    - **[[Technophiles]]** : Ceux qui sont passionnés par les nouvelles technologies et la transformation numérique.
    - **[[Minimalistes]]** : Ceux qui privilégient la simplicité et la frugalité dans leurs modes de vie.
10. **Les approches économiques et politiques :**
    
    - **[[Entrepreneurs]]** : Ceux qui créent des entreprises et développent des initiatives économiques.
    - **[[Militants]]** : Ceux qui s’engagent pour des causes sociales, environnementales ou politiques.
    - **[[Visionnaires]]** : Ceux qui imaginent de nouveaux systèmes politiques ou économiques.
    - **[[Administrateurs]]** : Ceux qui gèrent et organisent les ressources et les institutions.

En combinant ces différentes facettes, on obtiendrait une mosaïque très riche d'individus, chacun jouant un rôle essentiel dans l'équilibre global du monde. Ces catégories ne sont évidemment pas figées, et beaucoup de personnes pourraient appartenir à plusieurs d'entre elles en fonction des contextes et des situations.

> Et ceux qu'on a tendance à oublier ou à ne pas vouloir voir, et les gens qui ne parvienne pas à trouver leur place ?

Il y a effectivement des types de personnes que la société tend souvent à négliger, à marginaliser ou à rendre invisibles. Certaines d'entre elles peinent à trouver leur place dans les structures traditionnelles, ce qui peut être dû à diverses raisons, comme leur mode de vie, leurs compétences spécifiques, ou leurs croyances. Voici quelques exemples de ces groupes de personnes :

### 1. **Les invisibilisés ou marginalisés :**

- **Les sans-abris et précaires** : Ceux qui vivent dans des conditions extrêmement difficiles, sans logement stable, et qui sont souvent ignorés dans les décisions politiques et sociales.
- **Les personnes handicapées (physiques, mentales, cognitives)** : Malgré des progrès, beaucoup de lieux, d'institutions et de systèmes sont encore inadaptés à leurs besoins. Elles sont souvent oubliées dans les politiques publiques et peinent à accéder à l'emploi ou aux espaces publics.
- **Les personnes âgées isolées** : Celles qui, avec l'âge, perdent leurs proches ou leur mobilité et se retrouvent souvent coupées des autres et invisibles aux yeux de la société active.
- **Les migrants et réfugiés** : Ceux qui, forcés par les guerres, les crises économiques ou politiques, fuient leurs pays d'origine mais peinent à s'intégrer ou à être acceptés dans les sociétés d'accueil.
- **Les travailleurs de l’ombre** : Ceux qui font des emplois sous-payés, pénibles, souvent invisibles dans les métiers de service (nettoyage, agriculture, construction), essentiels à la société mais rarement valorisés.

### 2. **Les non-conformistes et ceux qui dévient des normes :**

- **Les artistes en rupture** : Ceux qui n’arrivent pas à s’adapter aux canons artistiques ou à en faire un métier viable, et qui se retrouvent souvent en marge des circuits culturels ou économiques.
- **Les personnes neuroatypiques** : Que ce soit les personnes autistes, hypersensibles, ou ayant des troubles de l’attention, elles peuvent avoir des difficultés à trouver leur place dans les systèmes éducatifs et professionnels qui privilégient des modes de pensée standardisés.
- **Les décrocheurs scolaires** : Ceux qui n'ont pas réussi à s'épanouir dans le cadre scolaire traditionnel et sont souvent stigmatisés comme "en échec", alors qu'ils pourraient s’épanouir dans d’autres environnements.
- **Les non-binaires et LGBTQ+ marginalisés** : Bien que les avancées pour les droits des personnes LGBTQ+ soient visibles, de nombreux individus, notamment ceux hors des grandes villes, continuent d’être rejetés, incompris ou discriminés en raison de leur identité ou orientation sexuelle.

### 3. **Les personnes en lutte avec la société et elles-mêmes :**

- **Les personnes atteintes de troubles mentaux** : Dépression, anxiété, bipolarité, ou schizophrénie, ces troubles sont encore mal compris et stigmatisés, rendant difficile pour ces personnes de s'intégrer dans un cadre traditionnel. Elles sont souvent exclues des systèmes de travail et de sociabilité.
- **Les personnes dépendantes** : Que ce soit la dépendance à l'alcool, aux drogues ou aux jeux, ces individus se retrouvent souvent dans des cycles d'exclusion sociale.
- **Les anciens détenus** : Après leur libération, ces personnes sont souvent confrontées à une stigmatisation sociale persistante et peinent à réintégrer la société ou à trouver un emploi stable.

### 4. **Les sous-représentés ou invisibilisés dans les récits dominants :**

- **Les femmes dans certains milieux (sciences, technologies, politiques)** : Malgré les progrès, dans beaucoup de secteurs, les femmes sont encore minoritaires et leurs contributions sont souvent invisibilisées ou dévalorisées.
- **Les communautés indigènes et minorités ethniques** : Ceux dont la culture, l'histoire et les droits sont souvent ignorés dans les politiques nationales ou internationales, et qui continuent de subir des discriminations structurelles.
- **Les introvertis et hypersensibles** : Dans un monde qui valorise l’extraversion, l’assertivité, et le dynamisme social, ces personnes peuvent se sentir inadaptées, bien que leurs qualités (écoute, sensibilité) soient précieuses dans d’autres contextes.

### 5. **Ceux qui refusent ou échappent au modèle socio-économique dominant :**

- **Les décroissants ou partisans du low-tech** : Ceux qui rejettent le consumérisme et prônent des modes de vie plus simples, autosuffisants, souvent perçus comme étant en marge du progrès technologique et économique dominant.
- **Les travailleurs informels ou alternatifs** : Ceux qui n’entrent pas dans le cadre des emplois traditionnels, comme les freelances précaires, les artistes indépendants, ou les travailleurs de l'économie collaborative (Uber, Deliveroo), souvent privés de sécurité sociale ou de protections.
- **Les militants radicaux** : Ceux qui adoptent des positions politiques ou sociales radicales (écologie, justice sociale, anti-capitalisme) et qui se heurtent aux résistances des systèmes établis, se retrouvant ainsi marginalisés ou criminalisés.

### 6. **Les personnes en errance identitaire ou de rôle :**

- **Les personnes en quête de sens** : Certaines personnes ne trouvent pas leur place dans les modèles de carrière ou de vie traditionnels, et peuvent se sentir perdues, constamment en quête de sens, sans parvenir à se fixer sur une trajectoire claire.
- **Les personnes sans identité claire dans une société multiculturelle** : Ceux qui naviguent entre plusieurs cultures, appartenances ou communautés, sans parvenir à s’intégrer complètement dans l’une ou l’autre.
- **Les rêveurs et utopistes** : Ceux qui envisagent un monde radicalement différent, mais qui sont souvent perçus comme déconnectés de la réalité, même s’ils apportent des visions nouvelles.

Ces types de personnes rappellent que la société, souvent fondée sur des normes et des attentes rigides, laisse peu de place à ceux qui ne rentrent pas dans les cases prédéfinies. Réfléchir à la manière de mieux inclure ces personnes – en créant des systèmes plus flexibles, en valorisant leurs compétences et en leur offrant des espaces d'expression – est crucial pour bâtir un monde où chacun peut trouver sa place, au-delà des catégories standards.

> Et ceux qu'on ne veut pas voir du tout ?

Il existe des groupes de personnes que la société, ou certaines parties de la société, préfère ne pas voir du tout, souvent parce qu'ils remettent en question des normes, provoquent un malaise, ou défient l'ordre établi. Ces groupes sont souvent stigmatisés, ignorés ou invisibilisés intentionnellement pour éviter de confronter des réalités difficiles. Voici quelques exemples de ces groupes :

### 7. **Les personnes en grande pauvreté ou exclusion extrême :**

- **Les sans-abris de longue durée** : Leur existence rappelle à la société les échecs des politiques sociales et économiques. Ils sont souvent perçus comme des "indésirables" dans les espaces publics, et il y a une tendance à les éloigner des zones touristiques ou résidentielles de prestige.
- **Les personnes vivant dans des bidonvilles ou camps de fortune** : Ces populations sont souvent déplacées ou ignorées, car elles incarnent la précarité extrême et les inégalités flagrantes dans les villes.

### 8. **Les personnes souffrant de graves troubles psychiques :**

- **Les personnes ayant des troubles mentaux graves et visibles** : Dans de nombreux cas, ces personnes, qui peuvent être errantes ou en situation de crise, sont évitées et mal prises en charge, car leur comportement déstabilise les normes sociales. Les institutions psychiatriques elles-mêmes sont souvent cachées ou négligées.
- **Les toxicomanes en situation de dégradation avancée** : Souvent perçus comme des figures de désespoir et d’échec, ces personnes sont rarement traitées avec dignité et sont souvent exclues des débats publics sur les solutions.

### 9. **Les criminels et anciens détenus :**

- **Les criminels violents** : La société tend à les diaboliser et à les expulser de la communauté sans se pencher sur les causes profondes de leur violence (société, santé mentale, etc.). Les solutions de réhabilitation sont souvent mal perçues ou insuffisantes.
- **Les anciens prisonniers, en particulier ceux ayant commis des crimes graves (meurtres, abus sexuels)** : Même après avoir purgé leur peine, ils sont souvent exclus, stigmatisés et privés de réelles opportunités de réintégration.

### 10. **Les travailleurs du sexe :**

- **Les prostituées et travailleurs du sexe** : Ils sont fréquemment marginalisés, même dans les sociétés où leur activité est légale. Ils subissent une stigmatisation intense et sont souvent tenus à l'écart des discours publics, invisibilisés dans les politiques sociales ou traités avec mépris moral.
- **Les victimes de la traite humaine** : Souvent invisibles, réduites au silence ou tenues dans des conditions proches de l'esclavage, elles sont ignorées parce que leur situation révèle des réalités sombres que beaucoup préfèrent ne pas affronter.

### 11. **Les personnes engagées dans des idéologies extrêmes ou violentes :**

- **Les extrémistes violents (terroristes, militants armés)** : Plutôt que de chercher à comprendre les raisons profondes qui les poussent à l'extrémisme, ces individus sont souvent vus uniquement comme des menaces à neutraliser, sans qu'une réelle réflexion ne soit engagée sur la prévention et la déradicalisation.
- **Les sectaires** : Les membres de cultes ou de mouvements sectaires, souvent perçus comme étant en rupture avec les valeurs sociales, sont généralement écartés ou mis sous silence.

### 12. **Les personnes en fin de vie ou mourantes :**

- **Les personnes en soins palliatifs ou confrontées à la mort imminente** : Dans une société qui valorise la jeunesse et la productivité, les personnes en fin de vie sont souvent oubliées ou reléguées à des institutions, loin du regard public. La mort elle-même est un sujet évité, car elle rappelle la fragilité et la mortalité de chacun.

### 13. **Les personnes associées à des comportements socialement inacceptables :**

- **Les pédophiles (même sans passage à l’acte)** : C’est l’un des groupes les plus stigmatisés et rejetés de la société, souvent perçu comme irrécupérable. Il existe très peu de soutien ou de réhabilitation pour ceux qui cherchent à contrôler leurs pulsions sans commettre de crime.
- **Les personnes avec des comportements déviants ou tabous** : Ceux qui expriment des désirs, des comportements ou des styles de vie jugés immoraux ou dangereux pour la société, comme ceux qui pratiquent des formes extrêmes de sadomasochisme ou de fétichisme, sont souvent cachés ou relégués aux marges de la société.

### 14. **Les enfants et adolescents délaissés :**

- **Les enfants des rues** : Dans certaines régions du monde, ces enfants, qui survivent sans soutien parental ni système de protection sociale, sont souvent ignorés par les institutions, devenant invisibles aux yeux du reste de la population.
- **Les jeunes radicalisés ou délinquants** : Plutôt que de les voir comme des individus en quête de réinsertion ou de compréhension, ils sont souvent criminalisés et stigmatisés dès leur plus jeune âge, sans que l'on cherche à comprendre les facteurs sociaux ou économiques derrière leur comportement.

### 15. **Les minorités opprimées ou "mal vues" :**

- **Les minorités ethniques marginalisées** : Dans certains contextes, des groupes ethniques minoritaires sont délibérément exclus ou réprimés, car leur existence même remet en cause les récits historiques dominants (les Rohingyas en Birmanie, les Ouïghours en Chine, etc.).
- **Les réfugiés et demandeurs d’asile en situation irrégulière** : En particulier dans les pays où les flux migratoires sont importants, ces personnes sont souvent vues comme des "problèmes" à résoudre plutôt que des êtres humains en quête de sécurité ou de meilleures conditions de vie.

### 16. **Les "perdus" dans les systèmes modernes :**

- **Les travailleurs déclassés (chômeurs longue durée, anciens cols blancs)** : Ceux qui, après avoir perdu leur emploi dans des secteurs en déclin (industrie, par exemple), ne parviennent pas à se réinsérer dans l'économie moderne. Ils sont souvent considérés comme inutiles ou non adaptés à la société moderne.
- **Les personnes exclues de la technologie** : Dans un monde de plus en plus numérisé, ceux qui ne peuvent pas ou ne veulent pas suivre la transition technologique (personnes âgées, illettrés numériques) deviennent de plus en plus invisibles et laissés pour compte.

### 17. **Les "échecs" du système économique :**

- **Les victimes du surendettement** : Ceux qui, pris dans des cycles de dettes inextricables, se retrouvent piégés dans la marginalité économique, souvent invisibles aux politiques publiques visant à aider les classes moyennes ou les personnes en emploi.
- **Les travailleurs invisibles des chaînes globales** : Beaucoup de travailleurs, notamment dans les pays en développement, produisent pour les grandes marques mondiales dans des conditions déplorables (exploitation, travail forcé, salaires misérables), mais sont invisibilisés pour ne pas troubler les consommateurs des pays riches.

Ces groupes représentent souvent des réalités inconfortables, celles que la société préfère ne pas regarder car elles révèlent des failles structurelles profondes : pauvreté, exclusion, inégalités, marginalisation. Reconnaître leur existence et comprendre leurs besoins spécifiques est essentiel pour créer une société plus juste et inclusive. Pourtant, bien souvent, ils sont réduits au silence ou cachés pour préserver une façade de normalité.

> Et les "méchants", du mauvais côté de l'histoire ?

Les "méchants", ou ceux que l'histoire considère comme étant du "mauvais côté", sont souvent des individus ou des groupes dont les actions sont perçues comme ayant eu un impact négatif, destructeur, ou contraire aux valeurs collectives dominantes à un moment donné. Ce qui est considéré comme le "mauvais côté de l'histoire" peut varier selon les points de vue, mais il y a certains profils qui émergent généralement lorsqu'on pense à ces figures :

### 18. **Les tyrans et dictateurs :**

- **Les despotes autoritaires** : Ceux qui prennent le pouvoir par la force ou la manipulation et gouvernent par la peur, l'oppression et la violence. Ils suppriment les libertés individuelles et maintiennent leur pouvoir par la répression, les purges et l'endoctrinement. Des figures historiques comme Hitler, Staline, ou Pol Pot sont généralement considérées comme des tyrans ayant laissé un lourd héritage de souffrance.
- **Les dirigeants corrompus** : Ceux qui abusent du pouvoir pour leur propre profit personnel et celui de leurs proches, aux dépens du bien-être général de la population. Ils sont souvent responsables de l’appauvrissement de leur pays et de la souffrance de leurs concitoyens.

### 19. **Les exploiteurs et oppresseurs :**

- **Les colonisateurs** : Ceux qui ont imposé leur domination à d'autres peuples, souvent par la violence et l'exploitation des ressources et des populations locales. Les empires coloniaux sont aujourd'hui largement considérés comme ayant perpétué des injustices profondes, laissant un héritage de souffrance et d'inégalité dans les pays colonisés.
- **Les esclavagistes** : Ceux qui ont justifié et profité de l'exploitation des êtres humains réduits en esclavage, considérant certains individus comme des biens de consommation. L'esclavage est largement reconnu comme l'un des crimes les plus graves contre l'humanité.

### 20. **Les oppresseurs idéologiques ou religieux :**

- **Les fanatiques religieux** : Ceux qui imposent leur vision du monde par la violence ou la coercition, persécutant ou tuant au nom de leurs croyances. Les croisades, l'Inquisition ou l'État islamique en sont des exemples. Ces personnes sont souvent vues comme étant du "mauvais côté de l'histoire" en raison de l'intolérance qu'elles imposent.
- **Les extrémistes politiques** : Ceux qui cherchent à imposer des idéologies radicales et totalitaires, menant souvent à des régimes répressifs (fascisme, communisme totalitaire, théocraties extrémistes). Ces systèmes sont souvent synonymes de massacres, de répression des libertés, et d'oppression généralisée.

### 21. **Les figures économiques prédatrices :**

- **Les magnats capitalistes sans scrupules** : Ceux qui exploitent les travailleurs et les ressources sans considération pour les droits humains ou l'impact environnemental. Ils sont souvent associés à des conditions de travail inhumaines, à l'exploitation des enfants, ou à la destruction de l'environnement. Les barons voleurs de la révolution industrielle ou les géants actuels des industries polluantes peuvent être perçus de cette manière.
- **Les corrupteurs et prédateurs financiers** : Ceux qui accumulent d'immenses fortunes en manipulant les systèmes économiques à leur avantage, au détriment des masses. Les crises économiques, souvent causées par des spéculations imprudentes ou des fraudes massives, sont vues comme la conséquence de leur avidité.

### 22. **Les génocidaires et bourreaux :**

- **Les responsables de génocides** : Ceux qui orchestrent des massacres systématiques de populations entières, souvent sur des bases ethniques, religieuses ou culturelles. Des figures comme Hitler (Holocauste), Milosevic (Balkans), ou les génocidaires du Rwanda sont des exemples de personnes qui, dans l’histoire, sont perçues comme des monstres pour leur rôle dans des atrocités massives.
- **Les tortionnaires** : Ceux qui utilisent la torture et les méthodes de violence extrême pour soumettre ou terroriser les autres. Les dictateurs et régimes répressifs utilisent souvent la torture pour briser les résistances et maintenir leur pouvoir.

### 23. **Les destructeurs de l’environnement :**

- **Les pollueurs industriels massifs** : Ceux qui, par négligence ou par quête de profit, détruisent des écosystèmes entiers, contribuent au changement climatique, ou provoquent des désastres écologiques (marées noires, déforestation massive, empoisonnement des rivières). Ces individus et entreprises sont souvent pointés du doigt pour leur contribution à la dégradation de la planète.
- **Les négationnistes du changement climatique** : Ceux qui, par intérêt personnel ou idéologique, nient ou minimisent l'impact de l'activité humaine sur l'environnement, retardant ainsi les actions nécessaires pour contrer les effets du réchauffement climatique.

### 24. **Les agents de haine et de division :**

- **Les propagandistes de la haine** : Ceux qui attisent la haine et les divisions raciales, ethniques, religieuses ou politiques, souvent à des fins de manipulation et de pouvoir. Ils sont responsables de violences et de conflits sociaux en exacerbant les tensions entre différents groupes.
- **Les ségrégationnistes et racistes** : Ceux qui prônent et imposent des systèmes de discrimination raciale ou de ségrégation (ex. : apartheid, ségrégation raciale aux États-Unis). Ces systèmes sont aujourd'hui universellement condamnés comme étant moralement inacceptables.

### 25. **Les profiteurs de guerre :**

- **Les marchands de mort** : Ceux qui s'enrichissent en vendant des armes et en alimentant des conflits dans le monde entier, sans se préoccuper des conséquences humaines. Les industries de l'armement et leurs acteurs, lorsqu'ils prolongent ou exacerbent des guerres, sont souvent perçus comme étant du mauvais côté de l'histoire.
- **Les architectes de guerres inutiles** : Ceux qui déclenchent des guerres pour des raisons politiques ou économiques sans raison valable. Ils sont responsables de la mort de millions de personnes pour des conflits évitables ou mal justifiés (ex. : Guerre en Irak, Guerre du Vietnam).

### 26. **Les manipulateurs et menteurs de masse :**

- **Les démagogues** : Ceux qui manipulent les émotions des masses pour leur propre pouvoir, en diffusant des mensonges ou des discours incendiaires. Ces figures sont souvent jugées comme étant des ennemis de la vérité et du bien commun.
- **Les conspirationnistes malveillants** : Ceux qui diffusent des théories du complot dangereuses, provoquant des divisions, la méfiance envers les institutions et, parfois, des violences. Ils exploitent la peur et l'incertitude pour leur propre profit ou pouvoir.

### 27. **Les scientifiques et industriels amoraux :**

- **Les expérimentateurs sans éthique** : Ceux qui mènent des expériences médicales, biologiques ou chimiques sur des êtres humains ou des animaux sans respect pour la dignité et la vie. Les expériences médicales sur les prisonniers de guerre, par exemple, sont aujourd'hui considérées comme l'un des aspects les plus monstrueux de la science utilisée à mauvais escient.
- **Les promoteurs d’innovations destructrices** : Ceux qui créent ou propagent des technologies ou des produits qui causent des dommages considérables à la société (ex. : industrie du tabac, industries chimiques dangereuses, création d'armes de destruction massive) sans se soucier des conséquences.

### 28. **Les traîtres et collaborateurs :**

- **Les collaborateurs avec des régimes oppressifs** : Ceux qui, pour leurs propres intérêts ou par opportunisme, collaborent avec des régimes répressifs, participent à la persécution de leur propre peuple ou facilitent les actions d'un régime oppressif.
- **Les traîtres à des causes justes** : Ceux qui trahissent leurs compagnons d’armes, leurs convictions ou leurs idéaux pour des gains personnels. L’histoire a tendance à juger durement ceux qui trahissent des mouvements de libération ou de résistance.

Ces groupes de "méchants" se retrouvent du "mauvais côté de l'histoire" car ils incarnent souvent l'injustice, la violence, l'oppression ou la destruction. Ce jugement est souvent influencé par les valeurs morales dominantes et les répercussions historiques de leurs actions. Toutefois, il est important de noter que ce que l'histoire retient comme "mauvais" peut aussi évoluer avec le temps et les contextes. Certaines figures jadis vénérées peuvent être réévaluées, et d'autres, initialement condamnées, peuvent être perçues sous un jour différent en fonction des nouvelles perspectives sociales et politiques.