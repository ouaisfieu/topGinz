# Altruisme
> Agir de manière désintéressée pour le bien-être d’autrui.
[[Valeurs sociales]]