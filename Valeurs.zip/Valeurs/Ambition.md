# Ambition
> Avoir des objectifs élevés et travailler dur pour les atteindre.
[[Valeurs de réalisation et d’accomplissement]]