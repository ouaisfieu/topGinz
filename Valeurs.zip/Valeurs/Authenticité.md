# Authenticité
> Être sincère et fidèle à soi-même, sans masque ni artifice.
[[Valeurs personnelles]]