# Beauté
> Apprécier et chercher la beauté dans les arts, la nature ou les objets.
[[Valeurs esthétiques]]