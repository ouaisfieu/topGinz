# Bienveillance
> Agir dans l'intérêt des autres avec gentillesse et altruisme.
[[Valeurs morales et éthiques]]