# Compassion
> Être sensible aux souffrances d’autrui et vouloir les soulager.
[[Valeurs morales et éthiques]]