# Compétition
> Désir de surpasser les autres ou de se mesurer à des standards élevés.
[[Valeurs de réalisation et d’accomplissement]]