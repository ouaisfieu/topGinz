# Coopération
> Travailler ensemble pour atteindre un but commun.
[[Valeurs sociales]]