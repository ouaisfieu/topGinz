# Courage
> Affronter la peur ou le danger pour défendre ses convictions.
[[Valeurs morales et éthiques]]