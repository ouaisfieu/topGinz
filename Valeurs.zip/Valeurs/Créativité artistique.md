# Créativité artistique
> Valoriser l’innovation et l’expression dans les arts.
[[Valeurs esthétiques]]