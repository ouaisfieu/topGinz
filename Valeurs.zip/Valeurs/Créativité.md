# Créativité
> Apprécier et promouvoir l'innovation et l'expression personnelle.
[[Valeurs personnelles]]