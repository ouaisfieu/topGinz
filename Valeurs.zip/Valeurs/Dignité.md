# Dignité
> Maintenir un comportement respectueux de soi-même et des autres.
[[Valeurs personnelles]]