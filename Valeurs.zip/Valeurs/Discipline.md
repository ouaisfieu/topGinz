# Discipline
> La capacité à maintenir un effort constant et à suivre des règles pour atteindre ses buts.
[[Valeurs de réalisation et d’accomplissement]]