# Droits de l’homme
> Protection des libertés et des droits fondamentaux.
[[Valeurs politiques et démocratiques]]