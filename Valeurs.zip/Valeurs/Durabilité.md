# Durabilité
> Agir de manière à préserver les ressources pour les générations futures.
[[Valeurs environnementales et planétaires]]