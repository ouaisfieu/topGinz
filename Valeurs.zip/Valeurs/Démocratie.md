# Démocratie
> Valoriser le gouvernement du peuple par le peuple.
[[Valeurs politiques et démocratiques]]