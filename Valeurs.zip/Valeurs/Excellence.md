# Excellence
> Recherche de la qualité et du meilleur dans toutes ses actions.
[[Valeurs de réalisation et d’accomplissement]]