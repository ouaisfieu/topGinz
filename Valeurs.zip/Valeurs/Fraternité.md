# Fraternité
> Sentiment d’amitié et de solidarité entre les membres d’une communauté.
[[Valeurs sociales]]