# Harmonie
> Rechercher l'équilibre et la cohérence visuelle ou sonore.
[[Valeurs esthétiques]]