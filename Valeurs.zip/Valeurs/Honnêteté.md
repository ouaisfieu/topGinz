# Honnêteté
> Dire la vérité et agir en toute transparence.
[[Valeurs morales et éthiques]]