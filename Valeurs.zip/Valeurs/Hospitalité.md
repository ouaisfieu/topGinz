# Hospitalité
> Accueillir les autres avec générosité et gentillesse.
[[Valeurs sociales]]