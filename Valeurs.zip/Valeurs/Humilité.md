# Humilité
> Reconnaître ses limites et ses imperfections, ne pas se surestimer.
[[Valeurs personnelles]]