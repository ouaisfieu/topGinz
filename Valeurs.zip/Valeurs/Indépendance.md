# Indépendance
> L’autonomie dans la prise de décision et le comportement.
[[Valeurs personnelles]]