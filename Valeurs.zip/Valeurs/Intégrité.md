# Intégrité
> Agir en cohérence avec ses principes moraux, même quand personne ne regarde.
[[Valeurs morales et éthiques]]