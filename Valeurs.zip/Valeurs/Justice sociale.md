# Justice sociale
> Lutte contre les inégalités et les injustices au sein de la société.
[[Valeurs politiques et démocratiques]]