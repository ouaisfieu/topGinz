# Justice
> Le respect de l’équité et de l’égalité des droits.
[[Valeurs morales et éthiques]]