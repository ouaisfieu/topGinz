# Liberté
> L’indépendance de penser, de s’exprimer, et d'agir sans contraintes indues.
[[Valeurs personnelles]]