# Loyauté
> Fidélité envers une personne, un groupe ou des principes.
[[Valeurs morales et éthiques]]