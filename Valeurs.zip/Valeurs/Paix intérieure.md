# Paix intérieure
> Un état de calme et d'équilibre mental.
[[Valeurs spirituelles et existentielles]]