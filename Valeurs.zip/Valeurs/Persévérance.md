# Persévérance
> Continuer à poursuivre ses objectifs malgré les obstacles.
[[Valeurs personnelles]]