# Respect
> Estimer autrui et ses droits, traiter les autres avec dignité.
[[Valeurs morales et éthiques]]