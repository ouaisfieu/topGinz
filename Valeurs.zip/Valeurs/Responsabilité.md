# Responsabilité
> Assumer ses actions et leurs conséquences.
[[Valeurs morales et éthiques]]