# Simplicité volontaire
> Privilégier un mode de vie simple et frugal, en consommant moins.
[[Valeurs environnementales et planétaires]]