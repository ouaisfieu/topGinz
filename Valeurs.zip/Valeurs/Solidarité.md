# Solidarité
> Soutenir les autres et collaborer pour atteindre des objectifs communs.
[[Valeurs sociales]]