# Tolérance
> Accepter les différences et la diversité des opinions et des modes de vie.
[[Valeurs morales et éthiques]]