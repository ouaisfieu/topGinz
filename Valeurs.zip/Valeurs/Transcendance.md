# Transcendance
> Chercher à aller au-delà des préoccupations matérielles pour atteindre une réalité supérieure.
[[Valeurs spirituelles et existentielles]]