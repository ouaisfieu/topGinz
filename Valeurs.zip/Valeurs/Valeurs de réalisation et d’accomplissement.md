#### 4. **Valeurs de réalisation et d’accomplissement** 

- **[[Succès]]** : Atteindre ses objectifs personnels et professionnels.
- **[[Excellence]]** : Recherche de la qualité et du meilleur dans toutes ses actions.
- **[[Compétition]]** : Désir de surpasser les autres ou de se mesurer à des standards élevés.
- **[[Ambition]]** : Avoir des objectifs élevés et travailler dur pour les atteindre.
- **[[Discipline]]** : La capacité à maintenir un effort constant et à suivre des règles pour atteindre ses buts.
- **[[Travail acharné]]** : Apprécier et valoriser l'effort et l'engagement dans son travail.