#### 6. **Valeurs environnementales et planétaires** 

- **[[Respect de la nature]]** : Avoir une attitude respectueuse envers l'environnement et les autres espèces.
- **[[Durabilité]]** : Agir de manière à préserver les ressources pour les générations futures.
- **[[Protection de l’environnement]]** : Valoriser la protection de l’écosystème et des ressources naturelles.
- **[[Harmonie avec la nature]]** : Vivre en accord avec les cycles et les équilibres naturels.
- **[[Simplicité volontaire]]** : Privilégier un mode de vie simple et frugal, en consommant moins.