#### 7. **Valeurs esthétiques** 

- **[[Beauté]]** : Apprécier et chercher la beauté dans les arts, la nature ou les objets.
- **[[Harmonie]]** : Rechercher l'équilibre et la cohérence visuelle ou sonore.
- **[[Créativité artistique]]** : Valoriser l’innovation et l’expression dans les arts.