#### 8. **Valeurs politiques et démocratiques** 

- **[[Liberté d’expression]]** : Le droit de s’exprimer sans censure ni répression.
- **[[PROJETS/CLASSEUR/VALEURS/Démocratie|Démocratie]]** : Valoriser le gouvernement du peuple par le peuple.
- **[[CRISP/droits de l’homme]]** : Protection des libertés et des droits fondamentaux.
- **[[Justice sociale]]** : Lutte contre les inégalités et les injustices au sein de la société.