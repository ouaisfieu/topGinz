# Équité
> Traiter chacun selon ses besoins et ses mérites.
[[Valeurs sociales]]