# Catégories par Action-Réaction

Action : [[motivé]], [[déterminé]], [[inspiré]]
Réaction : [[surpris]], [[choqué]], [[énervé]]