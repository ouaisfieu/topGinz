# Approche dimensionnelle (Russell & Scherer)**

Les émotions sont placées sur **deux axes principaux** :

- **Valence** : [[Positif]] (joie) ↔ [[Négatif]] (tristesse, peur).
- **Activation** : [[Haute énergie]] (colère, excitation) ↔ [[Basse énergie]] (sérénité, fatigue).

📌 **Intérêt de cette approche** : Elle permet de représenter les émotions de manière continue, sans catégories rigides.

Exemples:

- Positives : heureux, joyeux, satisfait
- Négatives : triste, en colère, anxieux