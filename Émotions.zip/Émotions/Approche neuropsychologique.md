# Approche neuropsychologique (Paul Ekman)**

Ekman identifie **6 émotions universelles**, basées sur des expressions faciales innées :

1. **[[Joie]]** 😊
2. **[[Tristesse]]** 😢
3. **[[Peur]]** 😨
4. **[[Colère]]** 😠
5. **[[Surprise]]** 😲
6. **[[Dégoût]]** 🤢

Il ajoute ensuite des émotions secondaires et culturelles comme la honte, la fierté ou la culpabilité.

📌 **Intérêt de cette approche** : Permet d’expliquer les émotions présentes dans toutes les cultures.