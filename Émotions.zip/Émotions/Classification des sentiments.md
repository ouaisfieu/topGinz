# Classification des sentiments (liée aux émotions)

Les **sentiments** découlent des émotions et sont souvent classés en grandes familles :

|**Famille de Sentiments**|**Exemples**|
|---|---|
|**Positifs** 😃|Amour, gratitude, fierté, espoir, confiance|
|**Négatifs** 😞|Haine, rancune, jalousie, honte, désespoir|
|**Neutres / Ambigus** 😐|Nostalgie, perplexité, admiration, curiosité|

📌 **Intérêt de cette approche** : Elle clarifie comment les émotions de base influencent les sentiments plus durables.