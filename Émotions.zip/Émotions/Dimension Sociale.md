# Catégories par Dimension Sociale

- Compassionnelles : [[compatissant]], [[sympathique]], [[empathique]]
- Compétitives : [[jaloux]], [[envieux]], [[rival]]