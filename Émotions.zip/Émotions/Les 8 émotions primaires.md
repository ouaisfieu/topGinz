# **Approche des émotions primaires et secondaires (Robert Plutchik)**

Plutchik propose une **roue des émotions**, où les émotions primaires se combinent pour former des émotions secondaires et complexes.

### **[[Les 8 émotions primaires]] :**

1. **[[Joie]]** 😊
2. **[[Tristesse]]** 😢
3. **[[Colère]]** 😠
4. **[[Peur]]** 😨
5. **[[Surprise]]** 😲
6. **[[Dégoût]]** 🤢
7. **[[Confiance]]** 🤝
8. **[[Anticipation]]** 🤔

🔄 **Émotions secondaires** : Elles résultent de la combinaison des émotions primaires.  
👉 Exemple :

- **Joie + Anticipation** = **Optimisme**
- **Colère + Dégoût** = **Mépris**

📌 **Intérêt de cette approche** : Elle montre comment les émotions interagissent et évoluent.