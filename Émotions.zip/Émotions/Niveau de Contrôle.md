# Catégories par Niveau de Contrôle

Contrôlables : [[calme]], [[motivé]], [[détendu]]
Non-Contrôlables : [[paniqué]], [[débordé]], [[terrifié]]