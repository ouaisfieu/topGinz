# Catégories par [[Origine]]

Internes : [[confiant]], [[fier]], [[honteux]]
Externes : [[rejeté]], [[accepté]], [[admiré]]