# Catégories par Relation Personnelle

- Sociales : [[aimé]], [[rejeté]], [[exclu]]
- Personnelles : [[fier]], [[honteux]], [[confiant]]