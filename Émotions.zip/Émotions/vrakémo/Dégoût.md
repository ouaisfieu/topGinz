# Dégoût

[[Désapprobation]]
[[Détestation]]
[[Gênant]]
[[Horrifique]]
[[Nauséabond]]
[[Répulsion]]
[[Révolte]]
