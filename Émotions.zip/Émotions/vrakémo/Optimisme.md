# Optimisme

**[[Joie]] + [[Anticipation]]** = **Optimisme**

Chaque fiche inclut :

- **Définition** de l’émotion.
- **Manifestations** physiques et mentales.
- **Origines possibles** (enfance, situation actuelle, valeurs, etc.).
- **Besoins sous-jacents** (ex: la tristesse peut cacher un besoin de connexion).
- **Stratégies d’apaisement et de transformation**.

