# Surprise

[[Choc]]
[[Consternation]]
[[Désillusion]]
[[Émerveillement]]
[[Énergisant]]
[[Étonnement]]
[[Impatience]]
[[Perplexité]]
