# Émotions

## Émotions et sentiments

Les **émotions** et les **sentiments** sont souvent confondus, mais ils ont des différences fondamentales, notamment dans leur durée, leur nature et leur origine.

---

### 1. **Définition et nature**

- **Émotions** : Réactions psychophysiologiques automatiques à un stimulus (interne ou externe). Elles sont instinctives et universelles (peur, joie, tristesse, colère…).
- **Sentiments** : Expériences subjectives plus durables, influencées par la réflexion et l’interprétation des émotions (amour, haine, confiance, jalousie…).

---

### 2. **Durée**

- **Émotions** : Brèves et intenses (quelques secondes ou minutes).
- **Sentiments** : Plus stables et persistants (heures, jours, voire années).

---

### 3. **Origine et processus**

- **Émotions** : Déclenchées automatiquement par le cerveau limbique (amygdale, hypothalamus). Elles sont biologiques et immédiates.
- **Sentiments** : Naissent de la réflexion et de l’interprétation des émotions par le cortex cérébral. Ils sont influencés par nos expériences, croyances et pensées.

---

### 4. **Exemple pour mieux comprendre**

1. **Émotion** : Vous voyez un chien agressif → **Peur** (réaction immédiate : cœur qui bat plus vite, adrénaline…).
2. **Sentiment** : Après plusieurs expériences négatives avec des chiens, vous développez un **sentiment d’anxiété** en leur présence, même si aucun danger immédiat n’est présent.

---

### 5. **Tableau récapitulatif**

|Critère|Émotion|Sentiment|
|---|---|---|
|**Nature**|Réaction instinctive|Construction cognitive|
|**Durée**|Brève|Longue|
|**Déclencheur**|Stimulation immédiate|Réflexion sur l’émotion|
|**Siège cérébral**|Limbique (amygdale)|Cortex cérébral|
|**Exemple**|Peur soudaine face à un bruit fort|Anxiété persistante liée à une phobie|

---

### 6. **Pourquoi cette distinction est-elle importante ?**

- **Mieux gérer ses réactions** : Comprendre qu’une émotion est passagère permet d’éviter les réactions impulsives.
- **Développer son [[intelligence émotionnelle]]** : Être capable d’identifier ses émotions et leurs transformations en sentiments permet une meilleure régulation.
- **Approfondir la compréhension des autres** : Reconnaître que les sentiments sont influencés par l’histoire et la perception de chacun aide à développer l’empathie.

👉 **En résumé** :

- Les **émotions** sont des réactions instinctives et biologiques.
- Les **sentiments** sont des constructions mentales plus durables basées sur l’interprétation des émotions.

## Classification ?

Il existe plusieurs **approches cohérentes** pour classer les émotions et les sentiments. Voici quelques méthodes qui permettent de structurer ces concepts de manière logique.

---

## **1. Approche des émotions primaires et secondaires (Robert Plutchik)**

Plutchik propose une **roue des émotions**, où les émotions primaires se combinent pour former des émotions secondaires et complexes.

### **[[Les 8 émotions primaires]] :**

1. **Joie** 😊
2. **Tristesse** 😢
3. **Colère** 😠
4. **Peur** 😨
5. **Surprise** 😲
6. **Dégoût** 🤢
7. **Confiance** 🤝
8. **Anticipation** 🤔

🔄 **Émotions secondaires** : Elles résultent de la combinaison des émotions primaires.  
👉 Exemple :

- **Joie + Anticipation** = **[[Optimisme]]**
- **Colère + Dégoût** = **Mépris**

📌 **Intérêt de cette approche** : Elle montre comment les émotions interagissent et évoluent.

---

## **2. [[Approche neuropsychologique]] (Paul Ekman)**

Ekman identifie **6 émotions universelles**, basées sur des expressions faciales innées :

1. **Joie** 😊
2. **Tristesse** 😢
3. **Peur** 😨
4. **Colère** 😠
5. **Surprise** 😲
6. **Dégoût** 🤢

Il ajoute ensuite des émotions secondaires et culturelles comme la honte, la fierté ou la culpabilité.

📌 **Intérêt de cette approche** : Permet d’expliquer les émotions présentes dans toutes les cultures.

---

## **3. [[Approche dimensionnelle]] (Russell & Scherer)**

Les émotions sont placées sur **deux axes principaux** :

- **Valence** : Positif (joie) ↔ Négatif (tristesse, peur).
- **Activation** : Haute énergie (colère, excitation) ↔ Basse énergie (sérénité, fatigue).

📌 **Intérêt de cette approche** : Elle permet de représenter les émotions de manière continue, sans catégories rigides.

---

## **4. [[Classification des sentiments]] (liée aux émotions)**

Les **sentiments** découlent des émotions et sont souvent classés en grandes familles :

|**Famille de Sentiments**|**Exemples**|
|---|---|
|**Positifs** 😃|Amour, gratitude, fierté, espoir, confiance|
|**Négatifs** 😞|Haine, rancune, jalousie, honte, désespoir|
|**Neutres / Ambigus** 😐|Nostalgie, perplexité, admiration, curiosité|

📌 **Intérêt de cette approche** : Elle clarifie comment les émotions de base influencent les sentiments plus durables.

---

## **5. Approche biologique et fonctionnelle**

- **Émotions de survie** : Peur (échapper au danger), colère (se défendre).
- **Émotions sociales** : Honte, fierté, culpabilité (régulent les interactions humaines).
- **Émotions esthétiques** : Émerveillement, fascination (liées à l’art, la contemplation).

📌 **Intérêt de cette approche** : Elle montre l’utilité des émotions dans notre évolution et nos interactions.

---

### **📌 Synthèse : Quelle classification choisir ?**

- **Besoin de structure simple** ? Plutchik ou Ekman.
- **Besoin d’une vision continue** ? Approche dimensionnelle.
- **Pour relier émotions et sentiments** ? Approche par familles de sentiments.
- **Pour comprendre le rôle des émotions** ? Approche fonctionnelle.

Tout dépend du contexte.

---

## Pour suivre

### **1. Suivi et journal émotionnel**

- Un modèle de `[[Journal des émotions]]` pour noter quotidiennement :
    - **Émotions ressenties**.
    - **Déclencheurs et contexte**.
    - **Réaction instinctive** et **réaction souhaitée**.
    - **Leçons et insights**.

### 📂 **Analyse et auto-coaching**

- `[[Carte des émotions récurrentes]]` pour identifier les tendances.
- `[[Facteurs d’influence]]` (santé, relations, environnement, hormones, sommeil).
- `[[Techniques de régulation émotionnelle]]` (respiration, écriture, ancrage).
- `[[Croyances liées aux émotions]]` : analyser si certaines émotions sont mal perçues à cause de l’éducation ou de la culture.

### 📂 **Interconnexion avec d’autres domaines**

- `[[Émotions et prises de décision]]`
- `[[Émotions et mémoire]]`
- `[[Émotions et créativité]]`
- `[[Émotions et relations sociales]]`


---

## Autres approches

Catégories par [[Relation Personnelle]]

Sociales : aimé, rejeté, exclu
Personnelles : fier, honteux, confiant

Catégories par [[Action-Réaction]]

Action : motivé, déterminé, inspiré
Réaction : surpris, choqué, énervé

Catégories par [[Origine]]

Internes : confiant, fier, honteux
Externes : rejeté, accepté, admiré

Catégories par [[Approche dimensionnelle|Valence]]

Positives : heureux, joyeux, satisfait
Négatives : triste, en colère, anxieux

Catégories par [[Dimension Sociale]]

Compassionnelles : compatissant, sympathique, empathique
Compétitives : jaloux, envieux, rival

Catégories par [[Niveau de Contrôle]]

Contrôlables : calme, motivé, détendu
Non-Contrôlables : paniqué, débordé, terrifié

Ces catégories peuvent aider à une analyse plus fine des émotions et peuvent être utilisées pour diverses applications comme la psychologie, le développement personnel, ou la gestion des émotions dans des contextes professionnels ou éducatifs.

---

Voir : [[1. Introspection]]

